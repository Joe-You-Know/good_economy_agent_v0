#!/usr/bin/env python3
"""Optional developer-side release inventory validation; not a runtime dependency."""
from pathlib import Path
import hashlib, json, sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'RELEASE_MANIFEST.json').read_text(encoding='utf-8'))
actual={str(p.relative_to(root)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest()
        for p in root.rglob('*') if p.is_file() and not any(x in ('build','build_sanitized','__pycache__') for x in p.relative_to(root).parts)
        and p.name!='RELEASE_MANIFEST.json'}
expected=manifest['sha256']
failures=[k for k in set(actual)|set(expected) if actual.get(k)!=expected.get(k)]
if failures:
    print('FAILED file inventory:',failures)
    sys.exit(1)
print(f'PASS: {len(expected)} inventoried source files match SHA-256')
