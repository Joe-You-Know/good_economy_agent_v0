#pragma once
#include "crnative/cache.hpp"
#include <cstdint>
#include <string>

namespace crnative {
enum class TransferMode { Auto, Full, Range };
struct DownloadRequest {
    Request cache;
    std::string url;
    TransferMode mode = TransferMode::Auto;
    std::uint64_t chunk_bytes = 1024 * 1024;
    unsigned group_chunks = 2;
    unsigned workers = 4;
    unsigned timeout_seconds = 30;
    bool fallback_full = false;
};
struct DownloadResult {
    Result cache_result;
    std::string network_mode;
    std::uint64_t resumed_chunks = 0;
    std::uint64_t range_requests = 0;
    std::uint64_t downloaded_bytes = 0;
    bool fallback_used = false;
};
DownloadResult download_verified(const DownloadRequest& request);
}
