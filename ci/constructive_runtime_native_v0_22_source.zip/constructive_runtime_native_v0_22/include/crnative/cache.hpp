#pragma once
#include "crnative/ledger.hpp"
#include "crnative/native_io.hpp"
#include <memory>
#include <string>

namespace crnative {
struct Result {
    std::string mode;
    std::string digest;
    std::uint64_t size = 0;
    bool cache_hit = false;
    bool published = false;
};
struct Request {
    fs::path cache_dir;
    fs::path destination;
    fs::path source; // only required on cold import
    std::string expected_digest;
    Size expected_size;
    std::string source_locator;
    std::string revision;
};
class Cache {
public:
    explicit Cache(fs::path cache_root);
    Result import_or_reuse(const Request& request, bool permit_source_import);
    fs::path object_path(const std::string& expected_digest) const;
    LedgerStats stats() const;
private:
    fs::path root_;
    std::unique_ptr<Ledger> ledger_;
};
}
