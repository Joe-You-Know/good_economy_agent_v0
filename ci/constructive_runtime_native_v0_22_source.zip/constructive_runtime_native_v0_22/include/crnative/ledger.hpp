#pragma once
#include <cstdint>
#include <filesystem>
#include <string>

struct sqlite3;
namespace crnative {
namespace fs = std::filesystem;

struct Observation {
    std::string digest;
    std::string operation;
    std::string source_locator;
    std::string revision;
    std::string output_path;
    std::uint64_t size = 0;
    std::string authority;
};
struct LedgerStats {
    std::uint64_t objects = 0;
    std::uint64_t observations = 0;
    std::uint64_t declared_bytes = 0;
};
class Ledger {
public:
    explicit Ledger(const fs::path& cache_dir);
    Ledger(const Ledger&) = delete;
    Ledger& operator=(const Ledger&) = delete;
    ~Ledger();
    void observe(const Observation& record);
    LedgerStats stats() const;
private:
    sqlite3* db_ = nullptr;
};
}
