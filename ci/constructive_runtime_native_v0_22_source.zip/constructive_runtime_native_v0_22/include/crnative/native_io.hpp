#pragma once
#include <cstdint>
#include <filesystem>
#include <optional>
#include <string>
#include <stdexcept>

namespace crnative {
namespace fs = std::filesystem;
using Size = std::optional<std::uint64_t>;

void ensure_directory(const fs::path& directory);
void reject_symlink(const fs::path& file);
void require_regular(const fs::path& file);
std::string validate_digest(std::string digest);
struct DigestMismatch : std::runtime_error { using std::runtime_error::runtime_error; };
struct VerifiedBytes {
    std::uint64_t size = 0;
    std::string digest;
};
VerifiedBytes hash_file(const fs::path& source);
VerifiedBytes verified_copy_atomic(const fs::path& source, const fs::path& destination,
                                  const std::string& expected_digest, Size expected_size = std::nullopt);
std::string json_escape(const std::string& text);
std::string path_utf8(const fs::path& p);
std::uint64_t timestamp_seconds();

// Process-scoped cooperation lock; intentionally NOT a permanent metadata trust assertion.
class FileLock {
public:
    explicit FileLock(const fs::path& lock_file);
    FileLock(const FileLock&) = delete;
    FileLock& operator=(const FileLock&) = delete;
    ~FileLock();
private:
#ifdef _WIN32
    void* handle_ = nullptr;
    void* overlapped_ = nullptr;
#else
    int fd_ = -1;
#endif
};
}
