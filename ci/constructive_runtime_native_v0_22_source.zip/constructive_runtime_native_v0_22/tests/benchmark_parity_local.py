"""Paired *process-level* local-CAS workload (not an in-process microbenchmark).
Usage: py tests/benchmark_parity_local.py NATIVE_EXEC V020_VENDOR_DIR [OUT_JSON]
Both methods verify file contents. No network, cold-fetch, or WAN claims.
"""
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys
import tempfile
import time

if len(sys.argv) not in (3,4):
    raise SystemExit('usage: benchmark_parity_local.py NATIVE V020_VENDOR_DIR [OUTPUT_JSON]')
exe = str(Path(sys.argv[1]).resolve())
vendor = Path(sys.argv[2]).resolve()
output = Path(sys.argv[3]).resolve() if len(sys.argv)==4 else None
sys.path.insert(0,str(vendor))
import constructive_runtime_transfer_v0_18 as v18

rounds=int(os.environ.get('CRNATIVE_BENCH_ROUNDS','5'))
sizes=[int(x) for x in os.environ.get('CRNATIVE_BENCH_SIZES','1,8,32').split(',')]
report={'schema':'crnative_v021_paired_local_cli_v1','rounds_per_method':rounds,
        'comparison_scope':'new destination from already populated verified CAS, process startup included, no network',
        'cases':[]}
for size_mib in sizes:
    with tempfile.TemporaryDirectory(prefix='crnative-pair-') as d:
        root = Path(d)
        source = root/'original'
        block = hashlib.sha256(b'constructive-runtime-native-v021').digest() * 32768
        with source.open('wb') as f:
            for _ in range(size_mib):f.write(block)
        digest = hashlib.sha256(source.read_bytes()).hexdigest()
        cases={}
        native_cache=root/'native-cache'
        python_cache=root/'python-cache'
        subprocess.run([exe,'import','--cache-dir',str(native_cache),'--source',str(source),
                        '--out',str(root/'native-seed'),'--expected-sha256',digest],check=True,capture_output=True)
        v18._store_cache_verified(source, v18._cache_path(python_cache,digest),digest,None)
        for kind in ('native','python-v020'):
            cases[kind]={'seconds':[],'modes':[],'sha256_verified':True}
        orders=[['native','python-v020'] if i%2==0 else ['python-v020','native'] for i in range(rounds)]
        for round_idx, order in enumerate(orders):
            for kind in order:
                dest=root/f'{kind}-{round_idx}.bin'
                if kind=='native':
                    args=[exe,'reuse','--cache-dir',str(native_cache),'--out',str(dest),'--expected-sha256',digest]
                else:
                    args=[sys.executable,str(vendor/'constructive_runtime_transfer_v0_20.py'),
                          'https://invalid.example/does-not-need-network',str(dest),'--mode','auto',
                          '--expected-sha256',digest,'--reuse-local','--cache-dir',str(python_cache),'--manage-cache']
                start=time.perf_counter()
                proc=subprocess.run(args,text=True,capture_output=True,timeout=60)
                duration=time.perf_counter()-start
                if proc.returncode:
                    raise RuntimeError(f'{kind} failed: {proc.stderr[-500:]}')
                result=json.loads(proc.stdout)
                if hashlib.sha256(dest.read_bytes()).hexdigest()!=digest:
                    raise RuntimeError(f'{kind} produced wrong bytes')
                mode=result.get('mode','')
                if kind=='native' and mode!='verified-cache-reuse':
                    raise RuntimeError(f'unexpected native mode {mode}')
                if kind=='python-v020' and result.get('local_reuse')!='cache':
                    raise RuntimeError(f'unexpected v0.20 mode {result}')
                cases[kind]['seconds'].append(round(duration,6))
                cases[kind]['modes'].append(mode)
                dest.unlink()
        report['cases'].append({'mib':size_mib,
                'native_median_seconds':round(statistics.median(cases['native']['seconds']),6),
                'python_v020_median_seconds':round(statistics.median(cases['python-v020']['seconds']),6),
                'methods':cases})
        print(size_mib, 'MiB:', 'native', report['cases'][-1]['native_median_seconds'],
              's, v0.20', report['cases'][-1]['python_v020_median_seconds'],'s',flush=True)
if output:
    output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
