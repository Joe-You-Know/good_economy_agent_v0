"""Controlled HTTP parity, integrity and interruption tests for the native engine."""
import hashlib, json, os, re, socket, subprocess, sys, tempfile, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import unittest

BINARY=str(Path(sys.argv[1]).resolve());sys.argv=[sys.argv[0]]
# 3 MiB + tail: tests grouped non-final and partial-final intervals.
BLOB=(bytes(range(256))*12590)+b'END-CHECKPOINT'
SHA=hashlib.sha256(BLOB).hexdigest()

class Server(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    def __init__(self, address, handler):
        super().__init__(address,handler)
        self.mode='range';self.version='"native-etag-v1"';self.calls=[];self.lock=threading.Lock()
        self.delay=0.;self.head_counter=0
class Handler(BaseHTTPRequestHandler):
    protocol_version='HTTP/1.1'
    def log_message(self, *args):pass
    def respond(self, method):
        server=self.server
        if self.path not in ('/artifact','/second'):
            self.send_error(404);return
        with server.lock:
            server.calls.append((method,self.path,self.headers.get('Range')))
            if method=='HEAD':server.head_counter+=1
        body=BLOB; etag=server.version
        if server.mode=='changed':
            body=bytes([BLOB[0]^0xFF])+BLOB[1:];etag='"native-etag-v2"'
        ranged=self.headers.get('Range')
        if method=='HEAD':
            self.send_response(200);self.send_header('Content-Length',str(len(body)))
            self.send_header('ETag',etag);self.send_header('Accept-Ranges','bytes')
            self.end_headers();return
        if ranged and server.mode not in ('ignore','ignore_truncated'):
            mt=re.fullmatch(r'bytes=(\d+)-(\d+)',ranged)
            if not mt:self.send_error(400);return
            start,end=map(int,mt.groups())
            if end>=len(body) or start>end:self.send_error(416);return
            payload=body[start:end+1]
            cr=f'bytes {start}-{end}/{len(body)}'
            if server.mode=='bad_range':cr=f'bytes {start+1}-{end}/{len(body)}'
            self.send_response(206);self.send_header('Content-Range',cr)
        else:
            payload=body
            self.send_response(200)
        self.send_header('Content-Length',str(len(payload)))
        self.send_header('ETag',etag)
        self.send_header('Connection','keep-alive')
        self.end_headers()
        if server.mode in ('slow','slow_then_kill'):
            for i in range(0,len(payload),16384):
                try:self.wfile.write(payload[i:i+16384]);self.wfile.flush()
                except (BrokenPipeError,ConnectionResetError):break
                time.sleep(server.delay)
        else:
            try:self.wfile.write(payload);self.wfile.flush()
            except (BrokenPipeError,ConnectionResetError):pass
    def do_HEAD(self):self.respond('HEAD')
    def do_GET(self):self.respond('GET')

class Network(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv=Server(('127.0.0.1',0),Handler)
        cls.th=threading.Thread(target=cls.srv.serve_forever,daemon=True);cls.th.start()
        cls.url=f'http://127.0.0.1:{cls.srv.server_address[1]}/artifact'
    @classmethod
    def tearDownClass(cls):cls.srv.shutdown();cls.srv.server_close();cls.th.join(3)
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='native-http-');self.addCleanup(self.tmp.cleanup)
        self.root=Path(self.tmp.name);self.cache=self.root/'cache';self.out=self.root/'out.bin'
        with self.srv.lock:self.srv.calls.clear();self.srv.mode='range';self.srv.version='"native-etag-v1"';self.srv.delay=0
    def cmd(self, mode='full', digest=SHA, fallback=False, out=None, url=None):
        cmd=[BINARY,'download','--cache-dir',str(self.cache),'--url',url or self.url,
             '--out',str(out or self.out),'--expected-sha256',digest,
             '--expected-size',str(len(BLOB)),'--mode',mode,'--chunk-kib','128',
             '--group-chunks','4','--workers','4','--timeout','15']
        if fallback:cmd.append('--fallback-full')
        return cmd
    def run_cmd(self,*args,ok=True,**kwargs):
        r=subprocess.run(self.cmd(*args,**kwargs),capture_output=True,text=True,timeout=30)
        if ok:self.assertEqual(r.returncode,0,r.stderr)
        else:self.assertNotEqual(r.returncode,0,r.stdout)
        return r
    def test_full_get_and_local_reuse(self):
        first=json.loads(self.run_cmd().stdout)
        self.assertEqual(first['mode'],'full-get')
        self.assertEqual(self.out.read_bytes(),BLOB)
        count=len(self.srv.calls)
        self.assertEqual(json.loads(self.run_cmd().stdout)['mode'],'verified-local')
        self.assertEqual(len(self.srv.calls),count)
    def test_parallel_ranges_and_digest(self):
        result=json.loads(self.run_cmd('range').stdout)
        self.assertEqual(result['mode'],'grouped-range')
        self.assertGreater(result['range_requests'],0)
        self.assertEqual(self.out.read_bytes(),BLOB)
        self.assertEqual(hashlib.sha256(self.out.read_bytes()).hexdigest(),SHA)
        self.assertTrue(any(x[2] for x in self.srv.calls))
    def test_bad_content_range_never_publishes(self):
        self.srv.mode='bad_range';self.out.write_bytes(b'sentinel')
        self.run_cmd('range',ok=False)
        self.assertEqual(self.out.read_bytes(),b'sentinel')
    def test_wrong_digest_preserves_destination(self):
        self.out.write_bytes(b'sentinel');self.run_cmd('full',digest='0'*64,ok=False)
        self.assertEqual(self.out.read_bytes(),b'sentinel')
    def test_wrong_range_digest_preserves_destination(self):
        self.out.write_bytes(b'sentinel');self.run_cmd('range',digest='0'*64,ok=False)
        self.assertEqual(self.out.read_bytes(),b'sentinel')
    def test_rejected_range_falls_back_if_permitted(self):
        self.srv.mode='ignore'
        result=json.loads(self.run_cmd('range',fallback=True).stdout)
        self.assertEqual(result['mode'],'full-get')
        self.assertTrue(result['fallback_used'])
        self.assertEqual(self.out.read_bytes(),BLOB)
    def test_rejected_range_without_fallback(self):
        self.srv.mode='ignore';self.run_cmd('range',ok=False)
        self.assertFalse(self.out.exists())
    def test_same_size_changed_source_cannot_publish(self):
        self.srv.mode='changed';self.run_cmd('range',ok=False)
        self.assertFalse(self.out.exists())
    def test_interrupted_resume(self):
        self.srv.mode='slow';self.srv.delay=0.003
        p=subprocess.Popen(self.cmd('range'),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        stage=self.cache/'.crnative'/'staging'
        valid=False
        for i in range(350):
            time.sleep(.025)
            if stage.exists() and any(x.suffix=='.state' for x in stage.iterdir()):
                try:
                    valid=any(sum(1 for l in x.read_text().splitlines()[5:] if len(l.split())==2)>=1 for x in stage.glob('*.state'))
                except OSError:pass
                if valid:break
            if p.poll() is not None:break
        self.assertTrue(valid,'at least one durable range checkpoint before kill')
        p.kill();p.communicate(timeout=5)
        self.srv.mode='range';self.srv.delay=0
        done=json.loads(self.run_cmd('range').stdout)
        self.assertGreater(done['resumed_chunks'],0)
        self.assertEqual(self.out.read_bytes(),BLOB)
    def test_corrupt_committed_chunk_redownloads(self):
        self.srv.mode='slow';self.srv.delay=.003
        p=subprocess.Popen(self.cmd('range'),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        stage=self.cache/'.crnative'/'staging'
        for _ in range(350):
            time.sleep(.025)
            states=list(stage.glob('*.state')) if stage.exists() else []
            if states and len(states[0].read_text().splitlines())>5:break
            if p.poll() is not None:break
        p.kill();p.communicate(timeout=5)
        for file in stage.glob('*.bin'):
            with file.open('r+b') as f:f.seek(0);f.write(b'INVALID-DATA')
        self.srv.mode='range';self.srv.delay=0
        done=json.loads(self.run_cmd('range').stdout)
        self.assertEqual(self.out.read_bytes(),BLOB)
        self.assertLess(done['resumed_chunks'],24)
    def test_no_untrusted_resume_after_head_etag_change(self):
        self.srv.mode='slow';self.srv.delay=.003
        p=subprocess.Popen(self.cmd('range'),stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        stage=self.cache/'.crnative'/'staging'
        for _ in range(350):
            time.sleep(.025)
            if stage.exists() and any(len(x.read_text().splitlines())>5 for x in stage.glob('*.state')):break
            if p.poll() is not None:break
        p.kill();p.communicate(timeout=5)
        self.srv.version='"new-etag-same-bytes"';self.srv.mode='range';self.srv.delay=0
        done=json.loads(self.run_cmd('range').stdout)
        self.assertEqual(done['resumed_chunks'],0)
        self.assertEqual(self.out.read_bytes(),BLOB)

if __name__=='__main__':unittest.main(verbosity=2)
