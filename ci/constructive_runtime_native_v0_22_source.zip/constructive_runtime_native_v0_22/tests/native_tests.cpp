#include "crnative/cache.hpp"
#include "crnative/native_io.hpp"
#include <chrono>
#include <fstream>
#include <functional>
#include <iostream>
#include <random>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>
using namespace crnative;
namespace {
int assertions = 0;
void check(bool condition, const std::string& message) {
    ++assertions;
    if (!condition) throw std::runtime_error("TEST FAILED: " + message);
}
template <typename F> void expect_error(F work, const std::string& message) {
    bool failed = false;
    try { work(); } catch (const std::exception&) { failed = true; }
    check(failed, message);
}
void put(const fs::path& path, const std::string& data) {
    std::ofstream out(path, std::ios::binary | std::ios::trunc);
    if (!out) throw std::runtime_error("test file open failed");
    out << data;
    if (!out) throw std::runtime_error("test file write failed");
}
std::string get(const fs::path& path) {
    std::ifstream in(path, std::ios::binary);
    return {std::istreambuf_iterator<char>(in), std::istreambuf_iterator<char>()};
}
struct Temp {
    fs::path dir;
    Temp() {
        std::random_device rd;
        dir = fs::temp_directory_path() / ("crnative-v021-" + std::to_string(timestamp_seconds()) + "-" + std::to_string(rd()));
        fs::create_directories(dir);
    }
    ~Temp() { std::error_code ec; fs::remove_all(dir, ec); }
};
}
int main() {
try {
    Temp temp;
    const auto cache_dir = temp.dir / "cas";
    const auto source = temp.dir / "origin.bin";
    const auto output = temp.dir / "result.bin";
    const auto second = temp.dir / "second.bin";
    put(source, "abc");
    const std::string abc = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
    const std::string zeros = "0000000000000000000000000000000000000000000000000000000000000000";
    check(hash_file(source).digest == abc, "SHA-256 official abc vector");
    check(hash_file(source).size == 3, "size counted");
    check(validate_digest("BA7816BF8F01CFEA414140DE5DAE2223B00361A396177A9CB410FF61F20015AD") == abc,
          "uppercase digest normalization");
    expect_error([&]{ validate_digest("broken"); }, "reject malformed trusted hash");
    Request req;
    req.cache_dir = cache_dir;
    req.source = source;
    req.destination = output;
    req.expected_digest = abc;
    req.expected_size = 3;
    req.source_locator = "https://example.invalid/first-source";
    req.revision = "rev-1";
    Cache cache(cache_dir);
    auto first = cache.import_or_reuse(req, true);
    check(first.mode == "verified-local-import" && first.published, "cold local import");
    check(get(output) == "abc", "cold published correct bytes");
    check(cache.object_path(abc) == cache_dir / "sha256" / "ba" / abc, "compatible v0.18 CAS path");
    check(get(cache.object_path(abc)) == "abc", "CAS content correct");
    auto stats = cache.stats();
    check(stats.objects == 1 && stats.observations == 1 && stats.declared_bytes == 3, "first ledger event");
    auto repeat = cache.import_or_reuse(req, true);
    check(repeat.mode == "verified-existing-output" && !repeat.published, "existing output rehashed and reused");
    req.source.clear();
    req.destination = second;
    req.source_locator = "https://example.invalid/second-source";
    req.revision = "rev-2";
    auto reused = cache.import_or_reuse(req, false);
    check(reused.mode == "verified-cache-reuse" && reused.cache_hit, "CAS reused without source");
    check(get(second) == "abc", "CAS output correct");
    stats = cache.stats();
    check(stats.objects == 1 && stats.observations == 3, "one blob, three distinct events");

    // Mutating output cannot cause a metadata-only acceptance.
    put(second, "bad");
    auto fixed = cache.import_or_reuse(req, false);
    check(fixed.mode == "verified-cache-reuse" && get(second) == "abc", "mutated existing output reconstructed");

    // Bad cached bytes never replace an existing destination. Their hash fails
    // while writing temp and temp cannot be published.
    put(cache.object_path(abc), "wrong cache bytes");
    put(second, "DO-NOT-REPLACE");
    expect_error([&]{ cache.import_or_reuse(req, false); }, "corrupt CAS refused");
    check(get(second) == "DO-NOT-REPLACE", "preexisting output survives failed CAS validation");
    put(source, "abc");
    req.source = source;
    auto repaired = cache.import_or_reuse(req, true);
    check(repaired.mode == "verified-local-import", "trusted source repairs corrupted CAS");
    check(get(second) == "abc" && get(cache.object_path(abc)) == "abc", "CAS repaired correctly");

    // Wrong expected hash / source size never publish any bytes.
    auto faildest = temp.dir / "protected.bin";
    put(faildest, "sentinel");
    Request wrong = req;
    wrong.destination = faildest;
    wrong.expected_digest = zeros;
    expect_error([&]{ cache.import_or_reuse(wrong, true); }, "wrong digest fails closed");
    check(get(faildest) == "sentinel", "wrong digest leaves old destination unchanged");
    wrong = req;
    wrong.destination = faildest;
    wrong.expected_size = 4;
    expect_error([&]{ cache.import_or_reuse(wrong, true); }, "wrong byte count fails closed");
    check(get(faildest) == "sentinel", "wrong size leaves old destination unchanged");

    // Source corruption cannot poison the CAS or publish bad output.
    put(source, "def");
    req.destination = temp.dir / "source-wrong.bin";
    // Present cache is known good; force different expected digest so importer
    // cannot use existing CAS and must check the supplied source.
    req.expected_digest = zeros;
    req.expected_size = 3;
    expect_error([&]{ cache.import_or_reuse(req, true); }, "wrong source digest rejected");
    check(!fs::exists(req.destination), "no destination published on source corruption");

    // A source symlink or CAS symlink is never followed.
    const auto symlink = temp.dir / "source-link.bin";
    std::error_code ec;
    fs::create_symlink(source, symlink, ec);
    if (!ec) {
        wrong = req; wrong.source = symlink;
        expect_error([&]{ cache.import_or_reuse(wrong, true); }, "source symlink refused");
    }
    req.expected_digest = abc;
    req.expected_size = 3;
    req.source.clear();
    req.destination = temp.dir / "link-check.bin";
    fs::remove(cache.object_path(abc));
    ec.clear();
    fs::create_symlink(source, cache.object_path(abc), ec);
    if (!ec)
        expect_error([&]{ cache.import_or_reuse(req, false); }, "symlink CAS refused");
    else
        std::cout << "NOTE: symlinks unavailable to test on this platform\n";
    fs::remove(cache.object_path(abc));

    // Concurrent threads must all verify independently and preserve outputs.
    put(source, "abc");
    std::vector<std::thread> threads;
    std::vector<std::string> errors(6);
    for (int i = 0; i < 6; ++i) {
        threads.emplace_back([&, i] {
            try {
                Cache other(cache_dir);
                Request r = req;
                r.source = source;
                r.destination = temp.dir / ("thread-" + std::to_string(i) + ".bin");
                other.import_or_reuse(r, true);
            } catch (const std::exception& e) { errors[i] = e.what(); }
        });
    }
    for (auto& t : threads) t.join();
    for (int i = 0; i < 6; ++i) {
        check(errors[i].empty(), "thread-safe import: " + errors[i]);
        check(get(temp.dir / ("thread-" + std::to_string(i) + ".bin")) == "abc", "thread output correct");
    }
    check(cache.stats().observations >= 10, "concurrent audit events preserved");
    std::cout << "PASS native foundation: " << assertions << " assertions\n";
    return 0;
} catch (const std::exception& e) {
    std::cerr << e.what() << "\n";
    return 1;
}
}
