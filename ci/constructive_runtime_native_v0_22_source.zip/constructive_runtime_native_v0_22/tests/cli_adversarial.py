"""Black-box CLI tests only. Runtime itself has no Python dependency."""
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import time
import threading
import unittest

BINARY = str(Path(sys.argv[1]).resolve())
sys.argv = [sys.argv[0]]

class NativeCLITests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="crnative-cli-")
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.cache = self.root / "artifacts"
        self.source = self.root / "origin.bin"
        self.out = self.root / "destination.bin"
        self.blob = b"abc" * 1437
        self.source.write_bytes(self.blob)
        self.sha = hashlib.sha256(self.blob).hexdigest()
    def call(self, command, *args, ok=True):
        r = subprocess.run([BINARY, command, *map(str, args)], text=True, capture_output=True, timeout=30)
        if ok and r.returncode:
            self.fail(f"code={r.returncode} stdout={r.stdout} stderr={r.stderr}")
        if not ok and not r.returncode:
            self.fail("unexpected successful operation")
        return r
    def opts(self, out=None):
        return ["--cache-dir", self.cache, "--out", out or self.out, "--expected-sha256", self.sha]
    def import_(self, out=None, source=None):
        return self.call("import", *self.opts(out), "--source", source or self.source,
                         "--source-uri", "https://source.example/model", "--revision", "rev-a")
    def test_cold_cache_and_repeat(self):
        first = json.loads(self.import_().stdout)
        self.assertEqual(first['mode'], 'verified-local-import')
        second = json.loads(self.call('reuse', *self.opts()).stdout)
        self.assertEqual(second['mode'], 'verified-existing-output')
        self.assertEqual(self.out.read_bytes(), self.blob)
        status = json.loads(self.call('status', '--cache-dir', self.cache).stdout)
        self.assertEqual(status['events'], 2)
    def test_cross_destination_reuse_without_source(self):
        self.import_()
        destination = self.root / 'new-out.bin'
        result = json.loads(self.call('reuse', *self.opts(destination)).stdout)
        self.assertEqual(result['mode'], 'verified-cache-reuse')
        self.assertEqual(destination.read_bytes(), self.blob)
    def test_corrupt_cache_and_guard_existing_output(self):
        self.import_()
        dest = self.root/'old.bin'
        dest.write_bytes(b'protected-data')
        (self.cache / 'sha256' / self.sha[:2] / self.sha).write_bytes(b'corruption')
        self.call('reuse', *self.opts(dest), ok=False)
        self.assertEqual(dest.read_bytes(), b'protected-data')
    def test_fake_ledger_cannot_authenticate_corrupt_data(self):
        self.import_()
        dest = self.root/'fresh.bin'
        dbpath = self.cache/'.crnative'/'ledger-v021.sqlite3'
        with sqlite3.connect(dbpath) as db:
            db.execute('UPDATE objects SET bytes=999999,last_verified_at=9999999999 WHERE digest=?',(self.sha,))
            db.commit()
        (self.cache/'sha256'/self.sha[:2]/self.sha).write_bytes(b'invalid')
        self.call('reuse', *self.opts(dest), ok=False)
        self.assertFalse(dest.exists())
    def test_wrong_hash_preserves_existing_target_and_source(self):
        self.out.write_bytes(b'original')
        self.call('import', *self.opts(), '--source', self.source, '--expected-size', len(self.blob)+1, ok=False)
        self.assertEqual(self.out.read_bytes(), b'original')
        self.assertEqual(self.source.read_bytes(), self.blob)
    def test_provenance_distinct_from_content(self):
        self.import_()
        dest = self.root/'second.bin'
        self.call('reuse', *self.opts(dest), '--source-uri','https://other.example/b','--revision','rev-b')
        with sqlite3.connect(self.cache/'.crnative'/'ledger-v021.sqlite3') as db:
            rows = db.execute('SELECT source_locator,source_revision FROM observations ORDER BY id').fetchall()
        self.assertEqual(len(rows), 2)
        self.assertNotEqual(rows[0],rows[1])
    def test_bad_digest_syntax(self):
        self.call('import','--cache-dir',self.cache,'--source',self.source,'--out',self.out,
                  '--expected-sha256','bogus',ok=False)
        self.assertFalse(self.out.exists())
    def test_existing_output_symlink_refused(self):
        target = self.root/'target-secret.txt'
        target.write_bytes(b'sentinel')
        try: self.out.symlink_to(target)
        except OSError: self.skipTest('symlinks not available')
        self.call('import', *self.opts(), '--source',self.source,ok=False)
        self.assertEqual(target.read_bytes(),b'sentinel')
    def test_parent_symlink_refused(self):
        other = self.root/'outside'
        other.mkdir()
        alias = self.root/'redirect'
        try: alias.symlink_to(other, target_is_directory=True)
        except OSError: self.skipTest('symlinks not available')
        self.call('import', '--cache-dir',alias/'cache','--source',self.source,
                  '--out',self.out,'--expected-sha256',self.sha,ok=False)
        self.assertFalse((other/'cache').exists())
    def test_parallel_process_import_uses_one_digest_object(self):
        results = []
        def task(i):
            dest = self.root / f'worker{i}.bin'
            results.append(self.import_(dest))
        threads = [threading.Thread(target=task,args=(i,)) for i in range(4)]
        for t in threads:t.start()
        for t in threads:t.join()
        self.assertEqual(len(results),4)
        with sqlite3.connect(self.cache/'.crnative'/'ledger-v021.sqlite3') as db:
            objects = db.execute('SELECT COUNT(*) FROM objects').fetchone()[0]
            events = db.execute('SELECT COUNT(*) FROM observations').fetchone()[0]
        self.assertEqual((objects,events),(1,4))
        for i in range(4):
            self.assertEqual((self.root/f'worker{i}.bin').read_bytes(),self.blob)
    def test_different_digests_same_destination_no_partial_publication(self):
        src2=self.root/'other-source.bin'
        src2.write_bytes(b'different-bytes' * 9216)
        sha2=hashlib.sha256(src2.read_bytes()).hexdigest()
        a=[BINARY,'import','--cache-dir',str(self.cache),'--source',str(self.source),
           '--out',str(self.out),'--expected-sha256',self.sha]
        b=[BINARY,'import','--cache-dir',str(self.cache),'--source',str(src2),
           '--out',str(self.out),'--expected-sha256',sha2]
        procs=[subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE) for cmd in (a,b)]
        for pr in procs:
            out,err=pr.communicate(timeout=20)
            self.assertEqual(pr.returncode,0,(out,err))
        self.assertIn(hashlib.sha256(self.out.read_bytes()).hexdigest(), {sha2,self.sha})
        with sqlite3.connect(self.cache/'.crnative'/'ledger-v021.sqlite3') as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM observations').fetchone()[0],2)

    def test_source_modified_mid_flow_fails_untampered(self):
        self.out.write_bytes(b'old')
        self.source.write_bytes(b'not expected contents')
        self.call('import', *self.opts(), '--source',self.source,ok=False)
        self.assertEqual(self.out.read_bytes(),b'old')
        tmp = list(self.out.parent.glob('.crnative-*.tmp'))
        self.assertEqual(tmp,[],f'temporary files leaked: {tmp}')
    def test_unicode_source_and_destination(self):
        directory = self.root / 'éphémère_日本語'
        directory.mkdir()
        source = directory / '入力.bin'
        destination = directory / 'résultat.bin'
        source.write_bytes(self.blob)
        self.import_(destination, source)
        self.assertEqual(destination.read_bytes(), self.blob)

    def test_kill_during_cache_staging_preserves_previous_destination(self):
        # A real subprocess is terminated while a nonempty uncommitted
        # temporary cache object exists. No testing hooks in production code.
        source = self.root / 'large-source.bin'
        dig = hashlib.sha256()
        block = b'a' * (1024 * 1024)
        with source.open('wb') as f:
            for _ in range(96):
                f.write(block)
                dig.update(block)
        sha = dig.hexdigest()
        self.out.write_bytes(b'previous verified output')
        proc = subprocess.Popen([BINARY,'import','--cache-dir',str(self.cache),
            '--source',str(source),'--out',str(self.out),'--expected-sha256',sha],
            stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        lock_dir = self.cache/'sha256'/sha[:2]
        saw_temporary = False
        deadline = time.monotonic() + 12
        while time.monotonic() < deadline and proc.poll() is None:
            temps = list(lock_dir.glob('.crnative-*.tmp'))
            if temps:
                try:
                    if temps[0].stat().st_size >= 1024 * 1024:
                        saw_temporary = True
                        proc.kill()
                        break
                except FileNotFoundError:
                    pass
            time.sleep(0.001)
        try: proc.communicate(timeout=10)
        finally:
            if proc.poll() is None: proc.kill(); proc.wait()
        if not saw_temporary:
            self.skipTest('process finished too quickly to observe in-flight temporary copy')
        self.assertEqual(self.out.read_bytes(),b'previous verified output')
        with sqlite3.connect(self.cache/'.crnative'/'ledger-v021.sqlite3') as db:
            self.assertEqual(db.execute('SELECT COUNT(*) FROM observations').fetchone()[0],0)
        # Recovery: next import can create a verified output from the source.
        recovered = self.call('import','--cache-dir',self.cache,'--source',source,
            '--out',self.out,'--expected-sha256',sha)
        self.assertEqual(json.loads(recovered.stdout)['mode'],'verified-local-import')
        self.assertEqual(hashlib.sha256(self.out.read_bytes()).hexdigest(),sha)

    def test_verify_subcommand(self):
        good = self.call('verify','--file',self.source,'--expected-sha256',self.sha)
        self.assertTrue(json.loads(good.stdout)['verified'])
        self.source.write_bytes(b'invalid')
        bad = self.call('verify','--file',self.source,'--expected-sha256',self.sha,ok=False)
        self.assertFalse(json.loads(bad.stdout)['verified'])

if __name__ == '__main__':
    unittest.main(verbosity=2)
