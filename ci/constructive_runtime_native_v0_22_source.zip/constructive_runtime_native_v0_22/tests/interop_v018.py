"""Optional interop check with the user's ORIGINAL v0.18 source (test-only). 
Usage: py tests/interop_v018.py PATH_TO_NATIVE_BINARY PATH_TO_V020_VENDOR_DIRECTORY
Never packages or imports Python into the native executable.
"""
import hashlib
from pathlib import Path
import subprocess
import sys
import tempfile

if len(sys.argv) != 3:
    raise SystemExit('usage: interop_v018.py BINARY V020_VENDOR_DIRECTORY')
exe = str(Path(sys.argv[1]).resolve())
vendor = Path(sys.argv[2]).resolve()
sys.path.insert(0, str(vendor))
import constructive_runtime_transfer_v0_18 as v18
with tempfile.TemporaryDirectory(prefix='crnative-parity-') as d:
    root = Path(d)
    source = root / 'source'
    source.write_bytes(hashlib.sha256(b'seed').digest() * 4097)
    sha = hashlib.sha256(source.read_bytes()).hexdigest()
    cache = root / 'cache'
    native_output = root / 'native-output'
    def native(command, path):
        subprocess.run([exe, command, '--cache-dir', str(cache), '--out', str(path),
                        '--expected-sha256', sha] + (['--source', str(source)] if command=='import' else []),
                       check=True, text=True, capture_output=True)
    # Native -> v0.18 original implementation.
    native('import',native_output)
    cas = v18._cache_path(cache,sha)
    assert cas == cache/'sha256'/sha[:2]/sha
    assert v18._verify(cas,sha,None)[0], 'native object failed original v0.18 verification'
    old_output = root/'v018-output'
    v18._copy_verified_atomic(cas,old_output,sha,None)
    assert old_output.read_bytes() == source.read_bytes()
    # v0.18 -> native: delete CAS, repopulate using unchanged v0.18 function.
    cas.unlink()
    v18._store_cache_verified(source,cas,sha,None)
    native_new = root/'native-from-v018'
    native('reuse',native_new)
    assert native_new.read_bytes() == source.read_bytes()
    print('PASS: native v0.21 <-> unchanged v0.18 CAS byte-level interoperability')
