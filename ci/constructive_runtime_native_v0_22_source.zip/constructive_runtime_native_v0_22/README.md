# Constructive Runtime Native v0.22 — Milestone 1

**Windows first, Linux second, macOS third.** v0.22 includes a native C++20 content-addressed cache plus a compiled libcurl HTTP transfer engine. It is **not yet full parity** with v0.20 economic selection, cache eviction, and lifecycle policies.

## What is implemented

- C++20 native executable `crnative` and static library `crnative_core`. **No Python runtime** is needed for actual use.
- OpenSSL EVP SHA-256: fully hashes existing outputs, and hashes every newly copied byte stream **as it is written** before publication. The caller must provide an independently trusted expected SHA-256; metadata is never integrity proof.
- Source-aware, timestamped SQLite/WAL observation ledger, with separate sources/revisions and independently recorded verification events.
- Same CAS object path as Python v0.18–v0.20: `CACHE/sha256/<first-two-hex>/<sha256>`; proven cross-read/write interoperability with the original v0.18 path and hash functions.
- OS-level cooperative per-destination **and** per-object locks: Windows `LockFileEx` / Linux and macOS `flock`. Locks release automatically on normal exit or process death. A fixed lock order prevents native processes targeting the same output with different digests from publishing simultaneously. No assertion of protection against noncooperating external writers or concurrent legacy Python processes.
- Temporary file created **exclusively in destination directory**, stream SHA-256 and optional length checked, flushed before rename. Bad bytes leave the previous destination intact. Windows `MoveFileExW` with `MOVEFILE_WRITE_THROUGH`; POSIX `rename` followed by directory `fsync`. Power-loss durability on NTFS/APFS has **not** yet been validated.
- One verification pass on warm-cache copy: verify **as copied**, rather than first hashing CAS and then hashing CAS again while copying. Receipts exist only inside the current operation; SQLite rows never grant future verification exemptions.
- Source file and CAS symlink/reparse-point rejection, cache root symlink rejection, destination symlink rejection, plus input validation. This is a cooperating-process cache, not yet a hostile multi-user sandbox.
- OS-aware Unicode CLI argument handling on Windows (`wmain`, UTF-16 → UTF-8); works with Unicode file paths on Linux in completed tests.

## Windows (primary target)

Prerequisites: Visual Studio 2022 with **Desktop development with C++**, CMake, Git, [official vcpkg](https://github.com/microsoft/vcpkg). Dependencies use **vetted native OpenSSL and SQLite**, not reimplemented TLS/cryptography/database primitives.

In PowerShell with `VCPKG_ROOT` pointing to the vcpkg checkout:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 `
  -DCMAKE_TOOLCHAIN_FILE="$env:VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake" `
  -DVCPKG_TARGET_TRIPLET=x64-windows-static -DBUILD_TESTING=ON
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
```

Executable: `build/Release/crnative.exe`.

**Windows testing status**: the actual hosted Windows x64 UCRT64 build and all three CTest suites passed at https://github.com/Joe-You-Know/good_economy_agent_v0/actions/runs/42442037292 . The MSVC/Visual Studio 2022 runner is a separate target; its first CI attempt used the wrong GitHub runner image and is being corrected to `windows-2022`. Do not claim MSVC success until its own build and tests pass.

## Linux (first validated host)

```sh
sudo apt-get install cmake g++ libssl-dev libsqlite3-dev libcurl4-openssl-dev pkg-config
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

## macOS (later)

GitHub Actions offers macOS hosted runners; the optional macOS job in `.github/workflows/native-platforms.yml` requires **manual dispatch** with `test_macos=true`. You don't need physical Mac hardware for automated builds and tests. The workflow is merely included, **not uploaded or activated**. Apple Silicon builds, APFS durability, codesigning and user experience remain untested.

## Use

First calculate the SHA-256 from an independently trusted registry/manifest. Do not treat a value supplied by the same untrusted source as independent authentication.

```powershell
# First local import to content-addressed cache and a verified destination:
.\build\Release\crnative.exe import --cache-dir .\artifacts --source .\source.bin --out .\output.bin --expected-sha256 YOUR_TRUSTED_SHA256 --source-uri "https://example.org/source.bin" --revision "immutable-source-revision"

# Verify/reuse an existing destination or the cached object; no source required:
.\build\Release\crnative.exe reuse --cache-dir .\artifacts --out .\another-output.bin --expected-sha256 YOUR_TRUSTED_SHA256

.\build\Release\crnative.exe verify --file .\another-output.bin --expected-sha256 YOUR_TRUSTED_SHA256
.\build\Release\crnative.exe status --cache-dir .\artifacts
```

All commands print a simple JSON result. `verify` exits 2 on a mismatched digest; other errors exit 1. The ledger's object statistics describe **historical verified digests**, not a current verified inventory and not physical disk usage. Never use it to skip rehashing bytes.

The `import` subcommand deliberately requires a local source. For native HTTP use **`download`** (documented below), with `auto` defaulting to a verified full GET and explicit `range` supporting durable resumable chunks. Quotas, dependency-aware eviction, quarantine, age/value calibration, and automated best-mode selection remain unported from the Python reference.

## Native architecture

| Module | Purpose |
|---|---|
| `platform_io.cpp` | Windows / POSIX handles, safe temporary copies, SHA-256 and publication, cooperative locks |
| `cache.cpp` | CAS lookup, verified import/reuse and single-use in-process event receipts |
| `ledger.cpp` | SQLite durable source/provenance and event journal, **no data authentication** |
| `main.cpp` | CLI, UTF-8 / Windows UTF-16 normalization |
| `tests/` | Direct native tests, black-box corruption/concurrency tests, optional original-v0.18 interop |

### Integrity and crash boundaries

- Wrong digest or size: no publication of unverified bytes; previous output untouched.
- Crash before atomic rename: previous output untouched, incomplete temporary files **may remain** for future safe cleanup; recovery cleanup is not implemented yet.
- Crash after CAS publication but before destination publication: CAS may exist with independently verified bytes; no source/receipt event can be assumed unless SQLite committed.
- Crash after destination publication but before SQLite: correct bytes may exist without a ledger event; next command verifies actual bytes again.
- SQLite row corruption or stale records: cannot authorize local reuse without independent SHA-256 of actual copied bytes.
- Noncooperating processes or malicious filesystem users: excluded from current lock threat model.

## Testing and next milestones

Milestone 1 (native cache): verified CAS import/reuse, source ledger, native I/O, concurrency/corruption tests. Parity with the original Python v0.18 CAS byte format is tested separately with `tests/interop_v018.py`. The Python reference is **not copied into the native runtime**.

Milestone 2 (v0.22): native libcurl HTTP download, per-worker connection reuse, staged-range recovery and trusted full-file SHA-256 **implemented and locally verified**. Actual Windows UCRT64 HTTP adversarial tests passed; cross-origin public WAN testing and the v0.16/v0.17 automatic mode selector are not yet complete.

Milestone 3: port v0.15–v0.17 mode/age/value policies and v0.19–v0.20 liveness/eviction/receipt ledger, with power-loss, quotas, and Windows cross-process tests.

Do not claim the entire v0.20 suite has been ported. Do not infer better WAN throughput from a faster local copy loop. This is a deliberately bounded, testable native foundation.


## Compiled HTTP transfer (native v0.22)

The native C++20 libcurl engine is built into `crnative`. The caller **must** supply an independent SHA-256 expected digest; destination publication is denied until it matches. No Python runtime required for the binary.

```powershell
py -m pip install pytest  # optional tests only; unittest requires no packages
.\build\Release\crnative.exe download --url https://example.com/artifact.bin --cache-dir .\artifacts --out .\result.bin --expected-sha256 YOUR_64_HEX_DIGEST --mode auto
```

`--mode auto` defaults to a digest-verified full GET unless a future, independently verified performance selector is ported. `--mode range --expected-size SIZE` enables native parallel grouped ranges with `--workers 4 --chunk-kib 1024 --group-chunks 2`. `--fallback-full` optionally retries a digest-verified full GET when ranges are rejected; no partial output can be published.

Range restarts are bound to the exact URL, trusted SHA, expected size, chunk geometry, and server strong ETag when present. Each canonical range has a durable SHA-256 checkpoint; on restart, all previously committed chunks are rehashed. The entire reconstructed file is SHA-256 checked before cache import and output publication. Without a strong ETag, no range chunks are reused across process restarts. Stage files are under `<cache>/.crnative/staging` and never published directly.

Linux: `sudo apt-get install libssl-dev libsqlite3-dev libcurl4-openssl-dev pkg-config cmake g++`.
Windows: Visual Studio 2022, vcpkg, and CMake; see Windows first workflow. macOS is configured but not yet verified.

**Unported:** v0.16/v0.17 performance calibration and forecast, v0.19 eviction/quarantine, automatic network benefit selection. Multi-process locks are cooperative, not hostile-process protection. Power-loss ordering needs actual Windows filesystem testing.
