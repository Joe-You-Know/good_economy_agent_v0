# Constructive Runtime Native v0.22 — compiled transfer milestone

## Implemented and tested locally

- Native C++20 with libcurl transfer orchestration, OpenSSL EVP SHA-256, SQLite native provenance, file locks and atomic publication. No Python dependency in runtime executable.
- Full GET: bounded bytes, status 200, independent whole-file SHA-256, file size if supplied, then import to immutable digest-derived cache path and publish verified destination.
- Range: explicit mode, exact HTTP 206 + Content-Range match, bounded grouped contiguous intervals, one reusable curl handle per worker, multiple workers. Strong ETag binding from HEAD (if supplied) with If-Range and exact ETag check on each range response.
- Crash recovery: source/expected-hash/geometry-separated stage, per-canonical chunk SHA-256, fsync stage before atomic state checkpoint. Restart rehashes all committed chunks. Missing/changed strong ETag refuses reuse. Final reconstructed whole-file digest checked prior to publishing. Unexpected range response may optionally fall back to full GET, with independent SHA-256 mandatory.
- Reused v0.21 native CAS, source-aware SQLite observation and interoperation with v0.18 Python cache format; no modification of native v0.21 core modules.
- Auto mode **conservatively full GET**, until native time/value-aware scheduler is implemented. Native cache lifecycle eviction, quotas and quarantine not yet ported.

## Local validation

Linux GCC and local libcurl/OpenSSL/SQLite, three CTest suites: 39 native foundation assertions, 15 CLI adversarial cases, 11 network adversarial cases. Complete Linux tests passed; `ctest --test-dir build --output-on-failure`.

New HTTP tests include full GET, no-network verified local reuse, grouped parallel ranges, source content changed with same length, invalid trusted SHA-256 with existing-output preservation, invalid Content-Range, ignored range refusal/fallback, server ETag change across restarts, corrupt staged chunk redownload and real process kill after at least one durable range checkpoint followed by successful resume.

## Correctness boundary

A server ETag is used only to identify response consistency; **it never proves byte integrity**. Only the caller-supplied independently trusted SHA-256 authenticates completed content. A per-range hash is a durability/recovery proof, not a replacement for whole-file integrity. Multi-process locks are cooperative, and hostile filesystem modification is not in scope.

## Deployment / CI

The Windows-first hosted-runner workflow exists in `.github/workflows/native-platforms.yml`. This source distribution alone does not mean Windows ran successfully; require an actual passing Windows Actions job, pinned commit and logs. GitHub repository association remains separate. macOS is manual opt-in and unverified.

## Limitations

Cross-platform Windows/macOS tests pending. Windows power-loss durability unverified. Network server behavior beyond the local adversarial fixture not audited yet. No HTTP/2 performance tuning, resume without strong ETag, adaptive worker count, automatic fastest-mode selection, cache eviction/quarantine, or multi-day fault stress tests. End-to-end native download benchmarks versus curl/HF are pending. The current implementation deliberately makes additional SHA-256 passes when crossing cache/publication boundaries.
