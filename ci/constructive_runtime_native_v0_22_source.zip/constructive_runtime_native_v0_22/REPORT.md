# Constructive Runtime Native v0.22 — compiled transfer milestone

## Implemented and tested locally

- Native C++20 with libcurl transfer orchestration, OpenSSL EVP SHA-256, SQLite native provenance, file locks and atomic publication. No Python dependency in runtime executable.
- Full GET: bounded bytes, status 200, independent whole-file SHA-256, file size if supplied, then import to immutable digest-derived cache path and publish verified destination.
- Range: explicit mode, exact HTTP 206 + Content-Range match, bounded grouped contiguous intervals, one reusable curl handle per worker, multiple workers. Strong ETag binding from HEAD (if supplied) with If-Range and exact ETag check on each range response.
- Crash recovery: source/expected-hash/geometry-separated stage, per-canonical chunk SHA-256, fsync stage before atomic state checkpoint. Restart rehashes all committed chunks. Missing/changed strong ETag refuses reuse. Final reconstructed whole-file digest checked prior to publishing. Unexpected range response may optionally fall back to full GET, with independent SHA-256 mandatory.
- Reused v0.21 native CAS, source-aware SQLite observation and interoperation with v0.18 Python cache format; no modification of native v0.21 core modules.
- Auto mode **conservatively full GET**, until native time/value-aware scheduler is implemented. Native cache lifecycle eviction, quotas and quarantine not yet ported.

## Local validation

Linux GCC and local libcurl/OpenSSL/SQLite, three CTest suites: 39 native foundation assertions, 15 CLI adversarial cases, 11 network adversarial cases. Complete Linux tests passed; `ctest --test-dir build --output-on-failure`.

New HTTP tests include full GET, no-network verified local reuse, grouped parallel ranges, source content changed with same length, invalid trusted SHA-256 with existing-output preservation, invalid Content-Range, ignored range refusal/fallback, server ETag change across restarts, corrupt staged chunk redownload and real process kill after at least one durable range checkpoint followed by successful resume.

## Correctness boundary

A server ETag is used only to identify response consistency; **it never proves byte integrity**. Only the caller-supplied independently trusted SHA-256 authenticates completed content. A per-range hash is a durability/recovery proof, not a replacement for whole-file integrity. Multi-process locks are cooperative, and hostile filesystem modification is not in scope.

## Deployment / CI

**Verified real Windows x64 result:** GitHub Actions UCRT64 run [42442037292](https://github.com/Joe-You-Know/good_economy_agent_v0/actions/runs/42442037292), based on private draft PR #4 / SHA `868084de634e3bcec4589d70c09132de116e09e4`, compiled the exact source snapshot and passed all three CTest suites (`native_foundation`, `native_cli_adversarial`, `native_http_adversarial`), total ~6.44s. This exposed and led to fixes of a MinGW-only compiler flag, Unicode wmain linkage, Windows junction/reparse-point rejection, and Python test harness SQLite handle closure.

**Not yet verified:** MSVC / Visual Studio 2022. Its initial run failed at configure because the `windows-2025` hosted image now uses Visual Studio 2026; switching the native CI workflow to `windows-2022` is required. The Windows UCRT64 success does not establish MSVC parity. Linux clean-archive CTest passed; macOS is manual opt-in and unverified. No protected main branch was modified; the code is in an isolated private CI branch.

## Limitations

MSVC and macOS tests pending; Windows UCRT64 adversarial tests passed. Windows power-loss durability unverified. Network server behavior beyond the local adversarial fixture not audited yet. No HTTP/2 performance tuning, resume without strong ETag, adaptive worker count, automatic fastest-mode selection, cache eviction/quarantine, or multi-day fault stress tests. Local comparisons versus curl were run: unconstrained 3.23MB curl 15.7ms, native full 71.2ms, native ranges 77.4ms (native slower); per-connection throttled curl 0.627s, native full 0.663s, native ranges 0.254s (ranges faster). These are controlled local conditions, not public-WAN or equal-workload performance proof. Hugging Face native downloader comparison is pending. The current implementation deliberately makes additional SHA-256 passes when crossing cache/publication boundaries.
