#include "crnative/ledger.hpp"
#include "crnative/native_io.hpp"
#include <sqlite3.h>
#include <cstdint>
#include <stdexcept>
#include <string>

namespace crnative {
namespace {
void sql_check(int rc, sqlite3* db, const char* action) {
    if (rc != SQLITE_OK && rc != SQLITE_DONE && rc != SQLITE_ROW)
        throw std::runtime_error(std::string(action) + ": " + sqlite3_errmsg(db));
}
void exec(sqlite3* db, const char* sql) {
    char* err = nullptr;
    const int rc = sqlite3_exec(db, sql, nullptr, nullptr, &err);
    if (rc != SQLITE_OK) {
        const std::string msg = err ? err : sqlite3_errmsg(db);
        sqlite3_free(err);
        throw std::runtime_error("SQLite: " + msg);
    }
}
class Stmt {
public:
    sqlite3_stmt* stmt = nullptr;
    explicit Stmt(sqlite3* db, const char* query) {
        sql_check(sqlite3_prepare_v2(db, query, -1, &stmt, nullptr), db, "prepare");
    }
    ~Stmt() { if (stmt) sqlite3_finalize(stmt); }
    Stmt(const Stmt&) = delete;
    Stmt& operator=(const Stmt&) = delete;
    void text(int idx, const std::string& val, sqlite3* db) {
        sql_check(sqlite3_bind_text(stmt, idx, val.c_str(), -1, SQLITE_TRANSIENT), db, "bind text");
    }
    void integer(int idx, std::uint64_t value, sqlite3* db) {
        sql_check(sqlite3_bind_int64(stmt, idx, static_cast<sqlite3_int64>(value)), db, "bind integer");
    }
    void done(sqlite3* db) { sql_check(sqlite3_step(stmt), db, "step"); }
};
}
Ledger::Ledger(const fs::path& cache_dir) {
    const fs::path meta = cache_dir / ".crnative";
    ensure_directory(meta);
    // Multiple processes can open a previously empty cache simultaneously.
    // Serialize WAL schema setup before normal per-object locking begins.
    FileLock schema_initializer(meta / "ledger-init.lock");
    auto path = meta / "ledger-v021.sqlite3";
    reject_symlink(path);
    reject_symlink(meta / "ledger-v021.sqlite3-wal");
    reject_symlink(meta / "ledger-v021.sqlite3-shm");
    const int rc = sqlite3_open_v2(path_utf8(path).c_str(), &db_,
            SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, nullptr);
    if (rc != SQLITE_OK) {
        const std::string msg = db_ ? sqlite3_errmsg(db_) : "open failed";
        if (db_) sqlite3_close(db_);
        db_ = nullptr;
        throw std::runtime_error("SQLite open failed: " + msg);
    }
    try {
        sqlite3_busy_timeout(db_, 5000);
        exec(db_, "PRAGMA foreign_keys=ON;");
        exec(db_, "PRAGMA journal_mode=WAL;");
        exec(db_, "PRAGMA synchronous=FULL;");
        exec(db_, "CREATE TABLE IF NOT EXISTS objects ("
             "digest TEXT PRIMARY KEY, bytes INTEGER NOT NULL, first_verified_at INTEGER NOT NULL, "
             "last_verified_at INTEGER NOT NULL, CHECK(length(digest)=64));");
        exec(db_, "CREATE TABLE IF NOT EXISTS observations ("
             "id INTEGER PRIMARY KEY AUTOINCREMENT, digest TEXT NOT NULL, event_at INTEGER NOT NULL, "
             "operation TEXT NOT NULL, source_locator TEXT NOT NULL, source_revision TEXT NOT NULL, "
             "output_path TEXT NOT NULL, bytes INTEGER NOT NULL, verification_authority TEXT NOT NULL, "
             "FOREIGN KEY(digest) REFERENCES objects(digest));");
        exec(db_, "CREATE INDEX IF NOT EXISTS observation_digest ON observations(digest);");
    } catch (...) { sqlite3_close(db_); db_ = nullptr; throw; }
}
Ledger::~Ledger() { if (db_) sqlite3_close(db_); }
void Ledger::observe(const Observation& r) {
    if (r.size > static_cast<std::uint64_t>(INT64_MAX))
        throw std::runtime_error("object size exceeds SQLite integer range");
    const std::uint64_t epoch = timestamp_seconds();
    exec(db_, "BEGIN IMMEDIATE;");
    try {
        {
            Stmt stmt(db_, "INSERT INTO objects(digest,bytes,first_verified_at,last_verified_at) "
                "VALUES(?,?,?,?) ON CONFLICT(digest) DO UPDATE SET "
                "bytes=excluded.bytes,last_verified_at=excluded.last_verified_at;");
            stmt.text(1, r.digest, db_);
            stmt.integer(2, r.size, db_);
            stmt.integer(3, epoch, db_);
            stmt.integer(4, epoch, db_);
            stmt.done(db_);
        }
        {
            Stmt stmt(db_, "INSERT INTO observations(digest,event_at,operation,source_locator,"
                "source_revision,output_path,bytes,verification_authority) VALUES(?,?,?,?,?,?,?,?);");
            stmt.text(1, r.digest, db_);
            stmt.integer(2, epoch, db_);
            stmt.text(3, r.operation, db_);
            stmt.text(4, r.source_locator, db_);
            stmt.text(5, r.revision, db_);
            stmt.text(6, r.output_path, db_);
            stmt.integer(7, r.size, db_);
            stmt.text(8, r.authority, db_);
            stmt.done(db_);
        }
        exec(db_, "COMMIT;");
    } catch (...) { try { exec(db_, "ROLLBACK;"); } catch (...) {} throw; }
}
LedgerStats Ledger::stats() const {
    LedgerStats out;
    {
        Stmt stmt(db_, "SELECT COUNT(*), COALESCE(SUM(bytes),0) FROM objects;");
        sql_check(sqlite3_step(stmt.stmt), db_, "objects stats");
        out.objects = static_cast<std::uint64_t>(sqlite3_column_int64(stmt.stmt, 0));
        out.declared_bytes = static_cast<std::uint64_t>(sqlite3_column_int64(stmt.stmt, 1));
    }
    {
        Stmt stmt(db_, "SELECT COUNT(*) FROM observations;");
        sql_check(sqlite3_step(stmt.stmt), db_, "observations stats");
        out.observations = static_cast<std::uint64_t>(sqlite3_column_int64(stmt.stmt, 0));
    }
    return out;
}
}
