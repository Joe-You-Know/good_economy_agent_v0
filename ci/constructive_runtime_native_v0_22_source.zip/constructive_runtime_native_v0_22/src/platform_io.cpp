#include "crnative/native_io.hpp"
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cctype>
#include <cerrno>
#include <cstring>
#include <iomanip>
#include <memory>
#include <stdexcept>
#include <system_error>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#else
#include <fcntl.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <unistd.h>
#endif

namespace crnative {
namespace {
constexpr std::size_t BLOCK = 1024 * 1024;
std::runtime_error problem(const std::string& what) { return std::runtime_error(what); }

std::string to_hex(const unsigned char* bytes, std::size_t length) {
    static constexpr char lut[] = "0123456789abcdef";
    std::string out;
    out.reserve(length * 2);
    for (std::size_t i = 0; i != length; ++i) {
        out.push_back(lut[bytes[i] >> 4]);
        out.push_back(lut[bytes[i] & 15]);
    }
    return out;
}
std::string secure_nonce() {
    std::array<unsigned char, 12> bits{};
    if (RAND_bytes(bits.data(), static_cast<int>(bits.size())) != 1)
        throw problem("OpenSSL RAND_bytes failed");
    return to_hex(bits.data(), bits.size());
}
struct Sha256 {
    EVP_MD_CTX* ctx = EVP_MD_CTX_new();
    Sha256() {
        if (!ctx || EVP_DigestInit_ex(ctx, EVP_sha256(), nullptr) != 1)
            throw problem("OpenSSL SHA-256 initialization failed");
    }
    ~Sha256() { if (ctx) EVP_MD_CTX_free(ctx); }
    Sha256(const Sha256&) = delete;
    Sha256& operator=(const Sha256&) = delete;
    void update(const void* ptr, std::size_t n) {
        if (EVP_DigestUpdate(ctx, ptr, n) != 1) throw problem("SHA-256 update failed");
    }
    std::string finish() {
        std::array<unsigned char, EVP_MAX_MD_SIZE> out{};
        unsigned int size = 0;
        if (EVP_DigestFinal_ex(ctx, out.data(), &size) != 1 || size != 32)
            throw problem("SHA-256 completion failed");
        return to_hex(out.data(), size);
    }
};

#ifdef _WIN32
std::runtime_error winerror(const std::string& what) {
    return problem(what + " (Win32 error " + std::to_string(GetLastError()) + ")");
}
class RawFile {
public:
    explicit RawFile(HANDLE handle) : h_(handle) {}
    ~RawFile() { if (h_ != INVALID_HANDLE_VALUE) CloseHandle(h_); }
    RawFile(const RawFile&) = delete;
    RawFile& operator=(const RawFile&) = delete;
    static std::unique_ptr<RawFile> input(const fs::path& p) {
        HANDLE h = CreateFileW(p.c_str(), GENERIC_READ,
                               FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
                               nullptr, OPEN_EXISTING, FILE_FLAG_OPEN_REPARSE_POINT, nullptr);
        if (h == INVALID_HANDLE_VALUE) throw winerror("open source failed");
        std::unique_ptr<RawFile> r(new RawFile(h));
        BY_HANDLE_FILE_INFORMATION info{};
        if (!GetFileInformationByHandle(h, &info)) throw winerror("inspect source failed");
        if ((info.dwFileAttributes & (FILE_ATTRIBUTE_DIRECTORY | FILE_ATTRIBUTE_REPARSE_POINT)) != 0)
            throw problem("refusing directory or reparse-point source");
        return r;
    }
    static std::unique_ptr<RawFile> output(const fs::path& p) {
        HANDLE h = CreateFileW(p.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW,
                               FILE_ATTRIBUTE_NORMAL, nullptr);
        if (h == INVALID_HANDLE_VALUE) throw winerror("exclusive temporary-file creation failed");
        return std::unique_ptr<RawFile>(new RawFile(h));
    }
    std::size_t read(unsigned char* p, std::size_t len) {
        DWORD n = 0;
        if (!ReadFile(h_, p, static_cast<DWORD>(len), &n, nullptr)) throw winerror("read failed");
        return n;
    }
    void write(const unsigned char* p, std::size_t len) {
        while (len) {
            DWORD n = 0;
            if (!WriteFile(h_, p, static_cast<DWORD>(len), &n, nullptr) || n == 0)
                throw winerror("write failed");
            p += n;
            len -= n;
        }
    }
    void flush() {
        if (!FlushFileBuffers(h_)) throw winerror("FlushFileBuffers failed");
    }
private:
    HANDLE h_ = INVALID_HANDLE_VALUE;
};
void publish(const fs::path& tmp, const fs::path& dest) {
    // Same-directory temp guarantees same-volume replacement. The Win32
    // filesystem's power-loss ordering still needs actual Windows testing.
    if (!MoveFileExW(tmp.c_str(), dest.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
        throw winerror("MoveFileExW publication failed");
}
#else
std::system_error posix_error(const std::string& what) {
    return std::system_error(errno, std::generic_category(), what);
}
class RawFile {
public:
    explicit RawFile(int fd) : fd_(fd) {}
    ~RawFile() { if (fd_ >= 0) ::close(fd_); }
    RawFile(const RawFile&) = delete;
    RawFile& operator=(const RawFile&) = delete;
    static std::unique_ptr<RawFile> input(const fs::path& p) {
        const int fd = ::open(p.c_str(), O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
        if (fd < 0) throw posix_error("open source failed");
        std::unique_ptr<RawFile> r(new RawFile(fd));
        struct stat s{};
        if (fstat(fd, &s) != 0) throw posix_error("fstat source failed");
        if (!S_ISREG(s.st_mode)) throw problem("refusing non-regular source");
        return r;
    }
    static std::unique_ptr<RawFile> output(const fs::path& p) {
        const int fd = ::open(p.c_str(), O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600);
        if (fd < 0) throw posix_error("exclusive temporary-file creation failed");
        return std::unique_ptr<RawFile>(new RawFile(fd));
    }
    std::size_t read(unsigned char* p, std::size_t len) {
        while (true) {
            const ssize_t n = ::read(fd_, p, len);
            if (n >= 0) return static_cast<std::size_t>(n);
            if (errno != EINTR) throw posix_error("read failed");
        }
    }
    void write(const unsigned char* p, std::size_t len) {
        while (len) {
            const ssize_t n = ::write(fd_, p, len);
            if (n < 0 && errno == EINTR) continue;
            if (n <= 0) throw posix_error("write failed");
            p += n;
            len -= static_cast<std::size_t>(n);
        }
    }
    void flush() {
        if (::fsync(fd_) != 0) throw posix_error("fsync temporary file failed");
    }
private:
    int fd_ = -1;
};
void publish(const fs::path& tmp, const fs::path& dest) {
    if (::rename(tmp.c_str(), dest.c_str()) != 0) throw posix_error("atomic rename failed");
    int d = ::open(dest.parent_path().c_str(), O_RDONLY | O_DIRECTORY | O_CLOEXEC | O_NOFOLLOW);
    if (d < 0) throw posix_error("open parent directory for fsync failed");
    if (::fsync(d) != 0) { const int saved = errno; ::close(d); errno = saved; throw posix_error("directory fsync failed"); }
    ::close(d);
}
#endif
}

std::string path_utf8(const fs::path& p) {
    auto u = p.u8string();
    return std::string(u.begin(), u.end());
}
std::uint64_t timestamp_seconds() {
    return static_cast<std::uint64_t>(std::chrono::duration_cast<std::chrono::seconds>(
        std::chrono::system_clock::now().time_since_epoch()).count());
}
void reject_symlink(const fs::path& p) {
    std::error_code ec;
    const auto status = fs::symlink_status(p, ec);
    if (!ec && fs::is_symlink(status)) throw problem("refusing symlink: " + path_utf8(p));
    if (ec && ec != std::errc::no_such_file_or_directory)
        throw problem("cannot inspect path: " + path_utf8(p) + ": " + ec.message());
}
void ensure_directory(const fs::path& directory) {
    if (directory.empty()) throw problem("directory path cannot be empty");
    const fs::path full = fs::absolute(directory).lexically_normal();
    fs::path cursor;
    for (const auto& part : full) {
        cursor /= part;
        reject_symlink(cursor);
    }
    fs::create_directories(full);
    if (!fs::is_directory(full)) throw problem("path is not a directory: " + path_utf8(full));
}
void require_regular(const fs::path& p) {
    reject_symlink(p);
    if (!fs::is_regular_file(p)) throw problem("not a regular file: " + path_utf8(p));
}
std::string validate_digest(std::string digest) {
    if (digest.size() != 64) throw problem("SHA-256 must contain exactly 64 hexadecimal characters");
    for (char& c : digest) {
        if (!std::isxdigit(static_cast<unsigned char>(c))) throw problem("non-hexadecimal SHA-256 character");
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    }
    return digest;
}
VerifiedBytes hash_file(const fs::path& source) {
    auto input = RawFile::input(source);
    Sha256 sha;
    std::vector<unsigned char> buffer(BLOCK);
    std::uint64_t n = 0;
    while (true) {
        const std::size_t count = input->read(buffer.data(), buffer.size());
        if (count == 0) break;
        sha.update(buffer.data(), count);
        n += count;
    }
    return VerifiedBytes{n, sha.finish()};
}
VerifiedBytes verified_copy_atomic(const fs::path& source, const fs::path& destination,
                                  const std::string& expected_digest, Size expected_size) {
    const std::string expected = validate_digest(expected_digest);
    ensure_directory(destination.parent_path());
    reject_symlink(destination);
    auto input = RawFile::input(source);
    const fs::path parent = destination.parent_path();
    fs::path tmp;
    std::unique_ptr<RawFile> output;
    for (int i = 0; i < 8; ++i) {
        tmp = parent / (".crnative-" + secure_nonce() + ".tmp");
        try { output = RawFile::output(tmp); break; }
        catch (const std::exception&) { if (fs::exists(tmp)) continue; throw; }
    }
    if (!output) throw problem("could not allocate exclusive temporary file");
    struct TempCleanup {
        fs::path file;
        ~TempCleanup() { std::error_code ignored; fs::remove(file, ignored); }
    } cleanup{tmp};
    Sha256 sha;
    std::vector<unsigned char> buffer(BLOCK);
    std::uint64_t bytes = 0;
    while (true) {
        const std::size_t count = input->read(buffer.data(), buffer.size());
        if (!count) break;
        output->write(buffer.data(), count);
        sha.update(buffer.data(), count);
        bytes += count;
    }
    output->flush();
    output.reset(); // Required for Windows rename semantics.
    auto actual = sha.finish();
    if (actual != expected || (expected_size && *expected_size != bytes))
        throw DigestMismatch("SHA-256 or size mismatch: refusing publication");
    reject_symlink(destination);
    publish(tmp, destination);
    return VerifiedBytes{bytes, actual};
}
std::string json_escape(const std::string& s) {
    std::string out = "\"";
    static constexpr char hex[] = "0123456789abcdef";
    for (unsigned char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) { out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15]; }
                else out += static_cast<char>(c);
        }
    }
    out += '"';
    return out;
}
FileLock::FileLock(const fs::path& lock_file) {
    ensure_directory(lock_file.parent_path());
    reject_symlink(lock_file);
#ifdef _WIN32
    HANDLE h = CreateFileW(lock_file.c_str(), GENERIC_READ | GENERIC_WRITE,
                           FILE_SHARE_READ | FILE_SHARE_WRITE,
                           nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL | FILE_FLAG_OPEN_REPARSE_POINT, nullptr);
    if (h == INVALID_HANDLE_VALUE) throw winerror("CreateFileW cache lock failed");
    handle_ = h;
    auto* o = new OVERLAPPED{};
    overlapped_ = o;
    if (!LockFileEx(h, LOCKFILE_EXCLUSIVE_LOCK, 0, 1, 0, o)) {
        const auto err = winerror("LockFileEx failed");
        CloseHandle(h); delete o; handle_ = nullptr; overlapped_ = nullptr; throw err;
    }
#else
    fd_ = ::open(lock_file.c_str(), O_CREAT | O_RDWR | O_CLOEXEC | O_NOFOLLOW, 0600);
    if (fd_ < 0) throw posix_error("open cache lock failed");
    while (::flock(fd_, LOCK_EX) != 0) {
        if (errno == EINTR) continue;
        const auto err = posix_error("flock failed"); ::close(fd_); fd_ = -1; throw err;
    }
#endif
}
FileLock::~FileLock() {
#ifdef _WIN32
    if (handle_) {
        auto* o = static_cast<OVERLAPPED*>(overlapped_);
        UnlockFileEx(static_cast<HANDLE>(handle_), 0, 1, 0, o);
        CloseHandle(static_cast<HANDLE>(handle_));
        delete o;
    }
#else
    if (fd_ >= 0) { ::flock(fd_, LOCK_UN); ::close(fd_); }
#endif
}
}
