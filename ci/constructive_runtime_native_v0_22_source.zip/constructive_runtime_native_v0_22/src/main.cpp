#include "crnative/cache.hpp"
#include "crnative/native_io.hpp"
#include "crnative/transfer.hpp"
#include <cstdint>
#include <iostream>
#include <vector>
#ifdef _WIN32
#include <windows.h>
#endif
#include <stdexcept>
#include <string>

using namespace crnative;
namespace {
void help() {
    std::cout << "Constructive Runtime Native v0.22 — compiled verified transfer engine\n\n"
                 "Usage:\n"
                 "  crnative import --cache-dir DIR --source FILE --out FILE --expected-sha256 HEX\n"
                 "        [--expected-size BYTES] [--source-uri LABEL] [--revision LABEL]\n"
                 "  crnative reuse --cache-dir DIR --out FILE --expected-sha256 HEX\n"
                 "        [--expected-size BYTES] [--source-uri LABEL] [--revision LABEL]\n"
                 "  crnative download --cache-dir DIR --url HTTP_URL --out FILE --expected-sha256 HEX\n"
                 "        [--expected-size BYTES] [--mode auto|full|range] [--fallback-full]\n"
                 "        [--chunk-kib 1024] [--group-chunks 2] [--workers 4] [--timeout 30]\n"
                 "  crnative verify --file FILE --expected-sha256 HEX [--expected-size BYTES]\n"
                 "  crnative status --cache-dir DIR\n\n"
                 "No destructive cache lifecycle operations in this milestone.\n";
}
std::string required(const std::string& value, const char* key) {
    if (value.empty()) throw std::runtime_error(std::string("missing ") + key);
    return value;
}
fs::path cli_path(const std::string& text) {
    // Windows command line is obtained as UTF-16 and explicitly converted to
    // UTF-8. Constructing fs::path from char8_t preserves non-ASCII filenames.
    std::u8string utf8;
    utf8.reserve(text.size());
    for (unsigned char byte : text) utf8.push_back(static_cast<char8_t>(byte));
    return fs::path(utf8);
}
std::uint64_t parse_size(const std::string& value) {
    if (value.empty() || value.front() == '-') throw std::runtime_error("invalid --expected-size");
    std::size_t end = 0;
    const auto n = std::stoull(value, &end, 10);
    if (end != value.size()) throw std::runtime_error("invalid --expected-size");
    return static_cast<std::uint64_t>(n);
}
}
int run_main(const std::vector<std::string>& argv) {
    const int argc = static_cast<int>(argv.size());
    try {
        if (argc <= 1 || std::string(argv[1]) == "--help" || std::string(argv[1]) == "help") {
            help(); return 0;
        }
        const std::string command = argv[1];
        std::string cache_dir, source, out, sha, source_uri, revision, verify_file, url, transfer_mode="auto";
        std::uint64_t chunk_kib=1024,group_chunks=2,workers=4,timeout=30;
        bool fallback_full=false;
        Size size;
        for (int i = 2; i < argc; ++i) {
            const std::string key = argv[i];
            if (key == "--fallback-full") {fallback_full=true;continue;}
            if (i + 1 >= argc) throw std::runtime_error("missing argument after " + key);
            const std::string value = argv[++i];
            if (key == "--cache-dir") cache_dir = value;
            else if (key == "--source") source = value;
            else if (key == "--out") out = value;
            else if (key == "--expected-sha256") sha = value;
            else if (key == "--expected-size") size = parse_size(value);
            else if (key == "--source-uri") source_uri = value;
            else if (key == "--revision") revision = value;
            else if (key == "--file") verify_file = value;
            else if (key == "--url") url = value;
            else if (key == "--mode") transfer_mode = value;
            else if (key == "--chunk-kib") chunk_kib = parse_size(value);
            else if (key == "--group-chunks") group_chunks = parse_size(value);
            else if (key == "--workers") workers = parse_size(value);
            else if (key == "--timeout") timeout = parse_size(value);
            else throw std::runtime_error("unknown option " + key);
        }
        if (command == "verify") {
            const auto checked = hash_file(cli_path(required(verify_file, "--file")));
            const auto expected = validate_digest(required(sha, "--expected-sha256"));
            const bool okay = checked.digest == expected && (!size || checked.size == *size);
            std::cout << "{\"verified\":" << (okay ? "true" : "false") << ",\"sha256\":"
                      << json_escape(checked.digest) << ",\"bytes\":" << checked.size << "}\n";
            return okay ? 0 : 2;
        }
        if (command == "status") {
            Cache cache(cli_path(required(cache_dir, "--cache-dir")));
            const auto s = cache.stats();
            std::cout << "{\"objects_observed\":" << s.objects << ",\"events\":" << s.observations
                      << ",\"declared_bytes_not_disk_usage\":" << s.declared_bytes << "}\n";
            return 0;
        }
        if (command == "download") {
            DownloadRequest download;
            download.cache.cache_dir=cli_path(required(cache_dir,"--cache-dir"));
            download.cache.destination=cli_path(required(out,"--out"));
            download.cache.expected_digest=required(sha,"--expected-sha256");
            download.cache.expected_size=size;
            download.url=required(url,"--url");
            download.cache.source_locator=download.url;
            download.cache.revision=revision;
            if(transfer_mode=="auto")download.mode=TransferMode::Auto;
            else if(transfer_mode=="full")download.mode=TransferMode::Full;
            else if(transfer_mode=="range")download.mode=TransferMode::Range;
            else throw std::runtime_error("invalid --mode");
            if(chunk_kib>UINT64_MAX/1024||group_chunks>32||workers>16||timeout>3600)throw std::runtime_error("invalid transfer limits");
            download.chunk_bytes=chunk_kib*1024;
            download.group_chunks=static_cast<unsigned>(group_chunks);
            download.workers=static_cast<unsigned>(workers);
            download.timeout_seconds=static_cast<unsigned>(timeout);
            download.fallback_full=fallback_full;
            const auto result=download_verified(download);
            std::cout<<"{\"mode\":"<<json_escape(result.network_mode)<<",\"sha256\":"
                <<json_escape(result.cache_result.digest)<<",\"bytes\":"<<result.cache_result.size
                <<",\"range_requests\":"<<result.range_requests<<",\"resumed_chunks\":"<<result.resumed_chunks
                <<",\"downloaded_bytes\":"<<result.downloaded_bytes
                <<",\"fallback_used\":"<<(result.fallback_used?"true":"false")<<"}\n";
            return 0;
        }
        if (command == "import" || command == "reuse") {
            Request request;
            request.cache_dir = cli_path(required(cache_dir, "--cache-dir"));
            request.destination = cli_path(required(out, "--out"));
            request.expected_digest = required(sha, "--expected-sha256");
            request.expected_size = size;
            request.source_locator = source_uri;
            request.revision = revision;
            if (command == "import") request.source = cli_path(required(source, "--source"));
            Cache cache(request.cache_dir);
            auto result = cache.import_or_reuse(request, command == "import");
            std::cout << "{\"mode\":" << json_escape(result.mode) << ",\"sha256\":"
                      << json_escape(result.digest) << ",\"bytes\":" << result.size
                      << ",\"cache_hit\":" << (result.cache_hit ? "true" : "false")
                      << ",\"published\":" << (result.published ? "true" : "false") << "}\n";
            return 0;
        }
        throw std::runtime_error("unknown subcommand " + command);
    } catch (const std::exception& e) {
        std::cerr << "crnative error: " << e.what() << '\n';
        return 1;
    }
}

#ifdef _WIN32
int wmain(int argc, wchar_t** argv) {
    std::vector<std::string> args;
    args.reserve(static_cast<std::size_t>(argc));
    for (int i = 0; i < argc; ++i) {
        const int required_chars = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS,
                                        argv[i], -1, nullptr, 0, nullptr, nullptr);
        if (required_chars <= 0) { std::cerr << "UTF-16 argument conversion failed\n"; return 1; }
        std::string temp(static_cast<std::size_t>(required_chars), '\0');
        if (!WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, argv[i], -1,
                                 temp.data(), required_chars, nullptr, nullptr)) return 1;
        temp.pop_back(); // remove terminating null
        args.push_back(std::move(temp));
    }
    return run_main(args);
}
#else
int main(int argc, char** argv) {
    return run_main(std::vector<std::string>(argv, argv + argc));
}
#endif
