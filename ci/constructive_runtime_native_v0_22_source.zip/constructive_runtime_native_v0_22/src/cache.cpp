#include "crnative/cache.hpp"
#include <stdexcept>
#include <utility>

namespace crnative {
namespace {
void checked_size(const VerifiedBytes& proof, Size expectation) {
    if (expectation && proof.size != *expectation)
        throw std::runtime_error("wrong file length despite hash verification");
}
// This evidence stays in the caller's stack, not SQLite. It exists ONLY after
// the final bytes were hashed and published. Never store it as a future trust bypass.
struct OneShotReceipt {
    VerifiedBytes value;
    fs::path destination;
    bool used = false;
    Observation consume(Observation info) {
        if (used || info.digest != value.digest || info.size != value.size ||
            info.output_path != path_utf8(destination))
            throw std::runtime_error("invalid or replayed verification handoff");
        used = true;
        return info;
    }
};
}
Cache::Cache(fs::path cache_root) {
    ensure_directory(cache_root);
    root_ = fs::absolute(cache_root).lexically_normal();
    ensure_directory(root_ / "sha256");
    ensure_directory(root_ / ".crnative" / "locks");
    ledger_ = std::make_unique<Ledger>(root_);
}
fs::path Cache::object_path(const std::string& expected_digest) const {
    const std::string digest = validate_digest(expected_digest);
    return root_ / "sha256" / digest.substr(0, 2) / digest;
}
LedgerStats Cache::stats() const { return ledger_->stats(); }
Result Cache::import_or_reuse(const Request& req, bool allow_import) {
    const auto digest = validate_digest(req.expected_digest);
    if (req.destination.empty()) throw std::runtime_error("output path is required");
    const auto destination = fs::absolute(req.destination).lexically_normal();
    const auto cache_obj = object_path(digest);
    if (destination == cache_obj || destination == root_ ||
        (destination.native().size() > root_.native().size() &&
         destination.native().compare(0, root_.native().size(), root_.native()) == 0 &&
         destination.native()[root_.native().size()] == fs::path::preferred_separator))
        throw std::runtime_error("destination must be outside the managed cache root");
    // The destination lock must be independent of the digest so that two
    // different sources cannot race to publish to the same output path.
    ensure_directory(destination.parent_path());
    fs::path dest_lock_path = destination;
    dest_lock_path += ".crnative.lock";
    FileLock destination_lock(dest_lock_path);
    const auto lock_path = root_ / ".crnative" / "locks" / (digest + ".lock");
    FileLock locked(lock_path); // destination -> object is a fixed lock order
    fs::path output_path = destination;
    reject_symlink(destination);
    std::string mode;
    VerifiedBytes checked;
    bool published = false;
    bool cache_hit = false;

    if (fs::exists(destination)) {
        require_regular(destination);
        checked = hash_file(destination);
        if (checked.digest == digest && (!req.expected_size || checked.size == *req.expected_size)) {
            mode = "verified-existing-output";
        }
    }
    if (mode.empty() && fs::exists(cache_obj)) {
        // The stream is hashed as it is copied, and its digest must match
        // BEFORE the temporary destination can be published. This one pass
        // replaces the earlier separate CAS prehash + copy-hash.
        require_regular(cache_obj);
        try {
            checked = verified_copy_atomic(cache_obj, destination, digest, req.expected_size);
            mode = "verified-cache-reuse";
            cache_hit = true;
            published = true;
        } catch (const DigestMismatch&) {
            // An invalid CAS cannot publish bytes. With a trusted source,
            // reconstruct it; otherwise report the missing valid artifact.
        }
    }
    if (mode.empty()) {
        if (!allow_import || req.source.empty())
            throw std::runtime_error("no verified local object; source import not permitted");
        if (!fs::exists(req.source)) throw std::runtime_error("source file is missing");
        ensure_directory(cache_obj.parent_path());
        // If CAS exists but failed verification, safe publication replaces it
        // only after matching caller's independently trusted digest.
        checked = verified_copy_atomic(req.source, cache_obj, digest, req.expected_size);
        // The cache object's content was just verified as written. Copy again
        // to destination and rehash as copied; no persistent digest exemption.
        checked = verified_copy_atomic(cache_obj, destination, digest, req.expected_size);
        mode = "verified-local-import";
        published = true;
    }
    checked_size(checked, req.expected_size);
    OneShotReceipt event{checked, output_path};
    // The caller supplies a claimed origin/revision; it is provenance metadata,
    // never independent proof that a URL served these bytes.
    Observation record;
    record.digest = digest;
    record.operation = mode;
    record.source_locator = req.source_locator.empty() ? (allow_import ? path_utf8(req.source) : "local-cache") : req.source_locator;
    record.revision = req.revision;
    record.output_path = path_utf8(output_path);
    record.size = checked.size;
    record.authority = "native-evp-sha256-verification-event-not-persistent-trust";
    ledger_->observe(event.consume(std::move(record)));
    return Result{mode, digest, checked.size, cache_hit, published};
}
}
