#include "crnative/transfer.hpp"
#include "crnative/native_io.hpp"
#include <curl/curl.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <algorithm>
#include <atomic>
#include <array>
#include <charconv>
#include <cstdio>
#include <fstream>
#include <future>
#include <iomanip>
#include <limits>
#include <mutex>
#include <sstream>
#include <stdexcept>
#include <thread>
#include <vector>
#include <cstring>
#ifdef _WIN32
#include <windows.h>
#else
#include <fcntl.h>
#include <unistd.h>
#endif

namespace crnative {
namespace {
struct ProtocolError : std::runtime_error { using std::runtime_error::runtime_error; };
struct NetworkError : std::runtime_error { using std::runtime_error::runtime_error; };
std::string sha(const unsigned char* ptr, std::size_t n) {
    unsigned char digest[EVP_MAX_MD_SIZE]{}; unsigned int len=0;
    if (EVP_Digest(ptr, n, digest, &len, EVP_sha256(), nullptr) != 1 || len!=32)
        throw std::runtime_error("native SHA-256 failed");
    static const char hexdigits[]="0123456789abcdef";
    std::string x; x.reserve(64);
    for(unsigned i=0;i<len;++i){x.push_back(hexdigits[digest[i]>>4]);x.push_back(hexdigits[digest[i]&15]);}
    return x;
}
std::string sha(const std::string& s){return sha(reinterpret_cast<const unsigned char*>(s.data()),s.size());}
std::string hex(const std::string& s){
    static const char* H="0123456789abcdef";
    std::string x; x.reserve(s.size()*2);
    for(unsigned char c:s){x.push_back(H[c>>4]);x.push_back(H[c&15]);}
    return x;
}
std::string unhex(const std::string& s) {
    if(s.size()%2) throw std::runtime_error("invalid hex length");
    std::string x;
    for(std::size_t i=0;i<s.size();i+=2){
        unsigned n=0;
        auto [ptr,ec]=std::from_chars(s.data()+i,s.data()+i+2,n,16);
        if(ec!=std::errc{}||ptr!=s.data()+i+2||n>255)throw std::runtime_error("invalid hex");
        x.push_back(static_cast<char>(n));
    }
    return x;
}
std::string nonce(){
    std::array<unsigned char,12> b{};
    if(RAND_bytes(b.data(),static_cast<int>(b.size()))!=1)throw std::runtime_error("secure nonce failure");
    return sha(b.data(),b.size()).substr(0,24);
}
void sync_file(const fs::path& file) {
#ifdef _WIN32
    HANDLE h=CreateFileW(file.c_str(),GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,OPEN_EXISTING,FILE_FLAG_OPEN_REPARSE_POINT,nullptr);
    if(h==INVALID_HANDLE_VALUE)throw std::runtime_error("stage flush open failed");
    const BOOL ok=FlushFileBuffers(h);CloseHandle(h);
    if(!ok)throw std::runtime_error("stage FlushFileBuffers failed");
#else
    int fd=::open(file.c_str(),O_RDONLY|O_CLOEXEC|O_NOFOLLOW);
    if(fd<0)throw std::runtime_error("stage fsync open failed");
    int rc=::fsync(fd);::close(fd);
    if(rc)throw std::runtime_error("stage fsync failed");
#endif
}
void sync_dir(const fs::path& dir) {
#ifndef _WIN32
    int fd=::open(dir.c_str(),O_RDONLY|O_DIRECTORY|O_CLOEXEC|O_NOFOLLOW);
    if(fd<0)throw std::runtime_error("directory fsync open failed");
    int rc=::fsync(fd);::close(fd);
    if(rc)throw std::runtime_error("directory fsync failed");
#else
    (void)dir;
#endif
}
void atomic_state(const fs::path& file,const std::string& content){
    auto tmp=file;tmp+= "."+nonce()+".tmp";
    try{
        reject_symlink(file);reject_symlink(tmp);
        {
            std::ofstream f(tmp,std::ios::binary|std::ios::trunc);
            if(!f)throw std::runtime_error("cannot create checkpoint");
            f.write(content.data(),static_cast<std::streamsize>(content.size()));f.flush();
            if(!f)throw std::runtime_error("checkpoint write failed");
        }
        sync_file(tmp);
#ifdef _WIN32
        if(!MoveFileExW(tmp.c_str(),file.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH))
            throw std::runtime_error("checkpoint replace failed");
#else
        if(::rename(tmp.c_str(),file.c_str())!=0)throw std::runtime_error("checkpoint replace failed");
        sync_dir(file.parent_path());
#endif
    }catch(...){std::error_code ec;fs::remove(tmp,ec);throw;}
}
void make_stage(const fs::path& path,std::uint64_t size){
    reject_symlink(path);
    {
        std::ofstream f(path,std::ios::binary|std::ios::trunc);
        if(!f)throw std::runtime_error("cannot create stage");
        if(size){f.seekp(static_cast<std::streamoff>(size-1));f.put('\0');}
        f.flush();if(!f)throw std::runtime_error("cannot size stage");
    }
    sync_file(path);
}
void stage_write(const fs::path& path,std::uint64_t at,const std::vector<unsigned char>& data){
    reject_symlink(path);
    std::fstream f(path,std::ios::binary|std::ios::in|std::ios::out);
    if(!f)throw std::runtime_error("stage missing");
    f.seekp(static_cast<std::streamoff>(at));
    f.write(reinterpret_cast<const char*>(data.data()),static_cast<std::streamsize>(data.size()));f.flush();
    if(!f)throw std::runtime_error("stage range write failed");
    f.close();sync_file(path);
}
std::string stage_chunk_hash(const fs::path& path,std::uint64_t at,std::uint64_t n){
    reject_symlink(path);
    std::ifstream f(path,std::ios::binary);
    if(!f)throw std::runtime_error("stage missing");
    f.seekg(static_cast<std::streamoff>(at));
    std::vector<unsigned char> data(static_cast<std::size_t>(n));
    f.read(reinterpret_cast<char*>(data.data()),static_cast<std::streamsize>(n));
    if(static_cast<std::uint64_t>(f.gcount())!=n)throw std::runtime_error("short staged range");
    return sha(data.data(),data.size());
}
std::string trim(std::string x){
    while(!x.empty()&&(x.back()=='\r'||x.back()=='\n'||x.back()==' '||x.back()=='\t'))x.pop_back();
    const auto p=x.find_first_not_of(" \t");return p==std::string::npos?"":x.substr(p);
}
std::string lower(std::string x){
    for(char& c:x)if(c>='A'&&c<='Z')c=static_cast<char>(c-'A'+'a');
    return x;
}
struct Headers{
    std::string range,etag;
    long status=0;
};
size_t header_cb(char* ptr,size_t n,size_t m,void* user){
    auto& h=*static_cast<Headers*>(user);
    const auto size=n*m;
    std::string s(ptr,size);
    if(s.starts_with("HTTP/")){h.range.clear();h.etag.clear();
        std::istringstream ss(s);std::string http;ss>>http>>h.status;}
    else if(auto p=s.find(':');p!=std::string::npos){
        std::string key=lower(trim(s.substr(0,p))),value=trim(s.substr(p+1));
        if(key=="content-range")h.range=value;
        else if(key=="etag")h.etag=value;
    }
    return size;
}
struct Data{std::vector<unsigned char>* data=nullptr;std::ofstream* stream=nullptr;std::uint64_t limit=UINT64_MAX;std::uint64_t count=0;bool excessive=false;};
size_t write_cb(char* ptr,size_t n,size_t m,void* user){
    auto& d=*static_cast<Data*>(user);
    if(n && m>SIZE_MAX/n)return 0;
    auto len=n*m;
    if(static_cast<std::uint64_t>(len)>d.limit-d.count){d.excessive=true;return 0;}
    if(d.data){auto* b=reinterpret_cast<unsigned char*>(ptr);d.data->insert(d.data->end(),b,b+len);}
    else if(d.stream){d.stream->write(ptr,static_cast<std::streamsize>(len));if(!*d.stream)return 0;}
    d.count+=len;
    return len;
}
struct CurlGlobal{
    CurlGlobal(){if(curl_global_init(CURL_GLOBAL_DEFAULT)!=0)throw NetworkError("libcurl init failed");}
    ~CurlGlobal(){curl_global_cleanup();}
};
struct Easy{
    CURL* h=curl_easy_init();
    explicit Easy(const std::string& url,unsigned timeout){
        if(!h)throw NetworkError("curl_easy_init failed");
        curl_easy_setopt(h,CURLOPT_URL,url.c_str()); // URL reset for each request below
        curl_easy_setopt(h,CURLOPT_FOLLOWLOCATION,1L);
        curl_easy_setopt(h,CURLOPT_MAXREDIRS,5L);
        curl_easy_setopt(h,CURLOPT_PROTOCOLS_STR,"http,https");
        curl_easy_setopt(h,CURLOPT_REDIR_PROTOCOLS_STR,"http,https");
        curl_easy_setopt(h,CURLOPT_SSL_VERIFYPEER,1L);
        curl_easy_setopt(h,CURLOPT_SSL_VERIFYHOST,2L);
        curl_easy_setopt(h,CURLOPT_CONNECTTIMEOUT,static_cast<long>(timeout));
        curl_easy_setopt(h,CURLOPT_TIMEOUT,static_cast<long>(timeout));
        curl_easy_setopt(h,CURLOPT_NOSIGNAL,1L);
        curl_easy_setopt(h,CURLOPT_TCP_KEEPALIVE,1L);
        curl_easy_setopt(h,CURLOPT_USERAGENT,"ConstructiveRuntimeNative/0.22");
    }
    ~Easy(){if(h)curl_easy_cleanup(h);}
    Easy(const Easy&)=delete;Easy&operator=(const Easy&)=delete;
};
void common(Easy& e,const std::string& url,Headers& head,Data& body){
    head={};body.count=0;body.excessive=false;
    curl_easy_setopt(e.h,CURLOPT_URL,url.c_str());
    curl_easy_setopt(e.h,CURLOPT_HEADERFUNCTION,header_cb);
    curl_easy_setopt(e.h,CURLOPT_HEADERDATA,&head);
    curl_easy_setopt(e.h,CURLOPT_WRITEFUNCTION,write_cb);
    curl_easy_setopt(e.h,CURLOPT_WRITEDATA,&body);
}
void perform(Easy& e){
    CURLcode rc=curl_easy_perform(e.h);
    if(rc!=CURLE_OK)throw NetworkError(std::string("HTTP transfer failed: ")+curl_easy_strerror(rc));
}
std::string head_etag(const std::string& url,unsigned timeout){
    Easy e(url,timeout);Headers h;Data d;common(e,url,h,d);
    curl_easy_setopt(e.h,CURLOPT_NOBODY,1L);perform(e);
    if(h.status!=200)throw ProtocolError("HEAD did not return HTTP 200");
    if(h.etag.starts_with("W/")||h.etag.empty())return "";
    return h.etag;
}
void download_full(const std::string& url,unsigned timeout,const fs::path& stage,std::uint64_t expected_max){
    reject_symlink(stage);
    std::ofstream f(stage,std::ios::binary|std::ios::trunc);
    if(!f)throw std::runtime_error("cannot allocate temporary download");
    Easy e(url,timeout);Headers h;Data d;d.stream=&f;d.limit=expected_max;
    common(e,url,h,d);
    curl_easy_setopt(e.h,CURLOPT_NOBODY,0L);curl_easy_setopt(e.h,CURLOPT_HTTPGET,1L);
    curl_easy_setopt(e.h,CURLOPT_RANGE,nullptr);
    perform(e);f.flush();if(!f)throw NetworkError("download file write failed");f.close();
    if(h.status!=200)throw ProtocolError("full GET did not return HTTP 200");
    sync_file(stage);
}
void exact_content_range(const std::string& range,std::uint64_t start,std::uint64_t end,std::uint64_t total){
    std::string expected="bytes "+std::to_string(start)+"-"+std::to_string(end)+"/"+std::to_string(total);
    if(range!=expected)throw ProtocolError("mismatched Content-Range: "+range);
}
struct Group{std::uint64_t begin=0,end=0;std::size_t first=0,last=0;};
struct Snapshot {
    std::string source_key,digest,etag;
    std::uint64_t total=0,chunk=0;
    std::vector<std::string> hashes;
};
std::string encode(const Snapshot& s){
    std::ostringstream o;
    o<<"CRNATIVE-RANGE-V1\n"<<s.source_key<<"\n"<<s.digest<<"\n"<<s.total<<" "<<s.chunk<<"\n"<<hex(s.etag)<<"\n";
    for(std::size_t i=0;i<s.hashes.size();++i)if(!s.hashes[i].empty())o<<i<<" "<<s.hashes[i]<<"\n";
    return o.str();
}
bool decode(const fs::path& file,Snapshot& s){
    std::ifstream f(file,std::ios::binary);
    if(!f)return false;
    std::string header,source,digest,etaghex;
    std::uint64_t total=0,chunk=0;
    if(!std::getline(f,header)||header!="CRNATIVE-RANGE-V1"||!std::getline(f,source)||!std::getline(f,digest)
       ||!(f>>total>>chunk))return false;
    f.ignore(std::numeric_limits<std::streamsize>::max(),'\n');
    if(!std::getline(f,etaghex))return false;
    try{
        if(source!=s.source_key||digest!=s.digest||total!=s.total||chunk!=s.chunk||unhex(etaghex)!=s.etag)return false;
        std::size_t idx;std::string hash;
        while(f>>idx>>hash){
            if(idx>=s.hashes.size()||!s.hashes[idx].empty()||validate_digest(hash)!=hash)return false;
            s.hashes[idx]=hash;
        }
        return f.eof();
    }catch(...){return false;}
}
std::vector<Group> groups(const Snapshot& s,unsigned width){
    std::vector<Group> out;
    for(std::size_t i=0;i<s.hashes.size();){
        if(!s.hashes[i].empty()){++i;continue;}
        auto last=i;
        while(last+1<s.hashes.size() && last-i+1<width && s.hashes[last+1].empty())++last;
        Group g;g.first=i;g.last=last;g.begin=i*s.chunk;
        g.end=std::min(s.total,(static_cast<std::uint64_t>(last)+1)*s.chunk)-1;
        out.push_back(g);i=last+1;
    }
    return out;
}
DownloadResult range_download(const DownloadRequest& req,const std::string& digest,const fs::path& data_file,const fs::path& state_file){
    if(!req.cache.expected_size || *req.cache.expected_size==0)throw ProtocolError("ranges require trusted expected size");
    const auto size=*req.cache.expected_size;
    const std::string etag=head_etag(req.url,req.timeout_seconds);
    const auto chunks=(size-1)/req.chunk_bytes+1;
    if(chunks>1000000)throw ProtocolError("too many range checkpoints");
    Snapshot s; s.source_key=sha(req.url+"\n"+digest);s.digest=digest;s.etag=etag;s.total=size;s.chunk=req.chunk_bytes;
    s.hashes.resize(static_cast<std::size_t>(chunks));
    reject_symlink(data_file);reject_symlink(state_file);
    bool resumed=false;
    if(!etag.empty()&&fs::exists(data_file)&&fs::exists(state_file)&&fs::file_size(data_file)==size){
        Snapshot loaded=s;
        if(decode(state_file,loaded)){
            s=std::move(loaded);resumed=true;
            for(std::size_t i=0;i<s.hashes.size();++i)if(!s.hashes[i].empty()){
                try{
                    const auto offset=static_cast<std::uint64_t>(i)*s.chunk;
                    const auto n=std::min(s.chunk,s.total-offset);
                    if(stage_chunk_hash(data_file,offset,n)!=s.hashes[i])s.hashes[i].clear();
                }catch(...){s.hashes[i].clear();}
            }
        }
    }
    if(!resumed){make_stage(data_file,size);std::error_code ignored;fs::remove(state_file,ignored);}
    // Reconcile the manifest after corruption checks, before scheduling new work.
    atomic_state(state_file,encode(s));
    DownloadResult output;output.network_mode="grouped-range";
    for(const auto& h:s.hashes)if(!h.empty())++output.resumed_chunks;
    auto jobs=groups(s,std::max(1U,req.group_chunks));
    std::mutex commit_lock,err_lock;
    std::exception_ptr first_error;
    std::atomic<std::size_t> next{0};
    std::atomic<bool> stop{false};
    std::atomic<std::uint64_t> transferred{0},requests{0};
    auto worker=[&] {
        try{
            Easy e(req.url,req.timeout_seconds);
            while(!stop.load()){
                const std::size_t task=next.fetch_add(1);
                if(task>=jobs.size())break;
                const auto& j=jobs[task];
                std::vector<unsigned char> bytes;bytes.reserve(static_cast<std::size_t>(j.end-j.begin+1));
                Headers h;Data data;data.data=&bytes;data.limit=j.end-j.begin+1;
                common(e,req.url,h,data);
                std::string range=std::to_string(j.begin)+"-"+std::to_string(j.end);
                curl_easy_setopt(e.h,CURLOPT_NOBODY,0L);curl_easy_setopt(e.h,CURLOPT_HTTPGET,1L);
                curl_easy_setopt(e.h,CURLOPT_RANGE,range.c_str());
                curl_slist* headers=nullptr;
                if(!etag.empty()){
                    headers=curl_slist_append(headers,("If-Range: "+etag).c_str());
                    if(!headers)throw std::runtime_error("curl header allocation failed");
                }
                curl_easy_setopt(e.h,CURLOPT_HTTPHEADER,headers);
                try{perform(e);}catch(...){curl_easy_setopt(e.h,CURLOPT_HTTPHEADER,nullptr);curl_slist_free_all(headers);throw;}
                curl_easy_setopt(e.h,CURLOPT_HTTPHEADER,nullptr);curl_slist_free_all(headers);
                if(h.status!=206)throw ProtocolError("HTTP ranges unsupported or rejected: status "+std::to_string(h.status));
                exact_content_range(h.range,j.begin,j.end,size);
                if(!etag.empty()&&h.etag!=etag)throw ProtocolError("strong ETag changed between HEAD and range response");
                if(bytes.size()!=j.end-j.begin+1)throw NetworkError("short HTTP range");
                std::lock_guard guard(commit_lock);
                // Verify canonical per-range hashes only after complete response and before durable checkpoint.
                stage_write(data_file,j.begin,bytes);
                for(std::size_t i=j.first;i<=j.last;++i){
                    const auto start=static_cast<std::uint64_t>(i)*s.chunk-j.begin;
                    const auto len=std::min(s.chunk,s.total-static_cast<std::uint64_t>(i)*s.chunk);
                    s.hashes[i]=sha(bytes.data()+static_cast<std::size_t>(start),static_cast<std::size_t>(len));
                }
                atomic_state(state_file,encode(s));
                requests.fetch_add(1);transferred.fetch_add(bytes.size());
            }
        }catch(...){
            stop.store(true);
            std::lock_guard guard(err_lock);if(!first_error)first_error=std::current_exception();
        }
    };
    std::vector<std::thread> threads;
    for(unsigned i=0;i<std::max(1U,std::min(req.workers,16U));++i)threads.emplace_back(worker);
    for(auto& t:threads)t.join();
    if(first_error)std::rethrow_exception(first_error);
    for(auto& h:s.hashes)if(h.empty())throw std::runtime_error("incomplete range ledger");
    const auto final=hash_file(data_file);
    if(final.digest!=digest||final.size!=size){
        std::error_code ignore;
        fs::remove(state_file,ignore);
        fs::remove(data_file,ignore);
        throw DigestMismatch("whole-file SHA-256 mismatch; stale stage invalidated without publication");
    }
    output.range_requests=requests.load();output.downloaded_bytes=transferred.load();
    return output;
}
} // namespace
DownloadResult download_verified(const DownloadRequest& req){
    if(req.url.empty())throw std::runtime_error("download URL missing");
    if(req.cache.destination.empty())throw std::runtime_error("destination required");
    const auto digest=validate_digest(req.cache.expected_digest);
    if(req.chunk_bytes<4096||req.chunk_bytes>64ULL*1024*1024)throw std::runtime_error("invalid --chunk-kib");
    if(req.group_chunks==0||req.group_chunks>32 || req.chunk_bytes>UINT64_MAX/req.group_chunks)
        throw std::runtime_error("invalid range group width");
    CurlGlobal global;
    Cache cache(req.cache.cache_dir);
    // Reuse the existing output or CAS only if the existing native core authenticates bytes again.
    try{
        auto reused=cache.import_or_reuse(req.cache,false);
        return DownloadResult{reused,"verified-local",0,0,0,false};
    }catch(const std::exception&){ /* no certified local reuse; download fresh */ }
    const auto stage_dir=fs::absolute(req.cache.cache_dir)/".crnative"/"staging";
    ensure_directory(stage_dir);
    const auto key=sha(req.url+"\n"+digest+"\n"+std::to_string(req.chunk_bytes)+"\n"+
        std::to_string(req.cache.expected_size.value_or(0)));
    FileLock lock(stage_dir/(key+".lock"));
    const auto stage=stage_dir/(key+".bin");
    const auto state=stage_dir/(key+".state");
    const auto full=stage_dir/(key+".full."+nonce()+".tmp");
    DownloadResult out;
    bool ready=false;
    if(req.mode==TransferMode::Range || (req.mode==TransferMode::Auto && false)){
        try{
            out=range_download(req,digest,stage,state);ready=true;
        }catch(const ProtocolError&){
            if(!req.fallback_full)throw;
            out.fallback_used=true;
        }catch(const NetworkError&){
            // Includes a range-ignoring 200 response which exceeds the bounded
            // range buffer. Explicit fallback retries a fresh full GET, never
            // trusting partially received bytes.
            if(!req.fallback_full)throw;
            out.fallback_used=true;
        }
    }
    fs::path from=stage;
    if(!ready){
        from=full;
        try{
            download_full(req.url,req.timeout_seconds,full,req.cache.expected_size.value_or(UINT64_MAX));
        }catch(...){std::error_code ignore;fs::remove(full,ignore);throw;}
        const auto checked=hash_file(full);
        if(checked.digest!=digest||(req.cache.expected_size&&*req.cache.expected_size!=checked.size)){
            std::error_code ignore;fs::remove(full,ignore);
            throw DigestMismatch("full GET independent SHA-256 mismatch; refusing publication");
        }
        out.network_mode="full-get";
        out.downloaded_bytes=checked.size;
    }
    try{
        Request local=req.cache;local.source=from;local.source_locator=req.url;
        out.cache_result=cache.import_or_reuse(local,true);
    }catch(...){if(from==full){std::error_code ignore;fs::remove(full,ignore);}throw;}
    std::error_code ignore;
    fs::remove(from,ignore);
    if(ready || out.fallback_used){
        fs::remove(state,ignore);
        if(out.fallback_used)fs::remove(stage,ignore);
    }
    return out;
}
} // namespace crnative
